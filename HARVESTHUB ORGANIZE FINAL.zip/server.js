// server.js - Node.js server for admin operations
const express = require('express');
const admin = require('firebase-admin');
const path = require('path');

// Initialize Firebase Admin SDK with service account
// Download your service account key from Firebase Console > Project Settings > Service Accounts
// Place the JSON file in your project directory (e.g., serviceAccountKey.json)
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  projectId: 'harvesthub-25071' // Your project ID
});

const app = express();
app.use(express.json());

// Serve static files from current directory
app.use(express.static(path.join(__dirname)));

// Function to delete user from both Auth and Firestore
async function deleteUserCompletely(uid) {
  try {
    // First, try to delete from Authentication
    try {
      await admin.auth().deleteUser(uid);
      console.log(`Successfully deleted user ${uid} from Authentication`);
    } catch (authError) {
      if (authError.code === 'auth/user-not-found') {
        console.warn(`User ${uid} not found in Authentication, continuing with Firestore deletion`);
      } else {
        throw new Error(`Failed to delete from Authentication: ${authError.message}`);
      }
    }

    // Then, try to delete from Firestore
    try {
      await admin.firestore().collection('users').doc(uid).delete();
      console.log(`Successfully deleted user ${uid} from Firestore`);
    } catch (firestoreError) {
      if (firestoreError.code === 5) { // NOT_FOUND
        console.warn(`User ${uid} not found in Firestore, continuing`);
      } else {
        throw new Error(`Failed to delete from Firestore: ${firestoreError.message}`);
      }
    }

    return { success: true, message: `User ${uid} deleted successfully` };

  } catch (error) {
    console.error(`Error deleting user ${uid}:`, error);
    return { success: false, message: error.message };
  }
}

// API endpoint for deleting users
app.delete('/api/users/:uid', async (req, res) => {
  const { uid } = req.params;

  if (!uid) {
    return res.status(400).json({ error: 'User ID is required' });
  }

  const result = await deleteUserCompletely(uid);

  if (result.success) {
    res.json(result);
  } else {
    res.status(500).json({ error: result.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = { deleteUserCompletely };