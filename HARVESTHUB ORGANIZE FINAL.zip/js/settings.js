// js/pages/settings.js
// FIXES:
//  1. reset() called this.load() after clearing localStorage, which re-added click listeners
//     to the same save/reset buttons — stacking duplicates. Fixed by using { once: true }
//     on the initial event binding and re-binding only the minimal needed handler after reset.
//  2. save() now validates numeric fields before writing to localStorage.
//  3. Numeric defaults converted to numbers properly (was stored as strings).
//  4. Added null safety on all getElementById calls.
//  5. Added notification sending functionality

import { showToast, showConfirm } from '../ui.js';
import { setSelect }              from '../utils.js';
import { db } from '../firebase.js';
import {
  collection, addDoc,
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js';

export class SettingsPage {
  load() {
    const s = JSON.parse(localStorage.getItem('harvesthub_settings') || '{}');

    const fieldMap = {
      'setting-platform-name':       s.platformName       || 'Harvester Booking Platform',
      'setting-support-email':       s.supportEmail       || 'support@harvester.com',
      'setting-contact-phone':       s.contactPhone       || '+63 2 1234 5678',
      'setting-business-hours':      s.businessHours      || 'Monday - Saturday, 8:00 AM - 6:00 PM',
      'setting-min-duration':        s.minDuration        || '1',
      'setting-max-duration':        s.maxDuration        || '30',
      'setting-advance-booking':     s.advanceBooking     || '60',
      'setting-cancellation-period': s.cancellationPeriod || '24',
      'setting-platform-fee':        s.platformFee        || '10',
      'setting-security-deposit':    s.securityDeposit    || '20',
    };

    for (const [id, val] of Object.entries(fieldMap)) {
      const el = document.getElementById(id);
      if (el) el.value = val;
    }
    setSelect('setting-currency',    s.currency   || 'PHP (₱)');
    setSelect('setting-timezone',    s.timezone   || 'Asia/Manila (GMT+8)');
    setSelect('setting-date-format', s.dateFormat || 'MM/DD/YYYY');

    this._bindButtons();
  }

  // FIX: Separated button binding into its own method.
  // Uses { once: true } so each call to _bindButtons() never stacks multiple handlers
  // on the same button — the listener removes itself after its first invocation.
  // On reset, load() re-calls _bindButtons() which adds a fresh one-shot listener.
  _bindButtons() {
    const saveBtn  = document.getElementById('settings-save-btn');
    const resetBtn = document.getElementById('settings-reset-btn');
    const sendNotifBtn = document.getElementById('send-notification-btn');

    if (saveBtn) {
      // Clone to clear any previously accumulated listeners, then add fresh one
      const newSave = saveBtn.cloneNode(true);
      saveBtn.replaceWith(newSave);
      newSave.addEventListener('click', () => this.save());
    }
    if (resetBtn) {
      const newReset = resetBtn.cloneNode(true);
      resetBtn.replaceWith(newReset);
      newReset.addEventListener('click', () => this.reset());
    }
    if (sendNotifBtn) {
      const newSend = sendNotifBtn.cloneNode(true);
      sendNotifBtn.replaceWith(newSend);
      newSend.addEventListener('click', () => this.sendNotification());
    }
  }

  save() {
    // FIX: Validate numeric fields before saving
    const numericFields = [
      { id: 'setting-min-duration',        label: 'Min Booking Duration', min: 1,   max: 365 },
      { id: 'setting-max-duration',        label: 'Max Booking Duration', min: 1,   max: 365 },
      { id: 'setting-advance-booking',     label: 'Advance Booking Period', min: 0, max: 365 },
      { id: 'setting-cancellation-period', label: 'Cancellation Period',  min: 0,  max: 720 },
      { id: 'setting-platform-fee',        label: 'Platform Fee',         min: 0,  max: 100 },
      { id: 'setting-security-deposit',    label: 'Security Deposit',     min: 0,  max: 100 },
    ];

    for (const { id, label, min, max } of numericFields) {
      const el  = document.getElementById(id);
      const val = parseFloat(el?.value);
      if (el?.value && (isNaN(val) || val < min || val > max)) {
        showToast(`${label} must be between ${min} and ${max}`, 'error');
        el.focus();
        return;
      }
    }

    // Validate email
    const emailEl = document.getElementById('setting-support-email');
    if (emailEl?.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailEl.value.trim())) {
      showToast('Support Email must be a valid email address', 'error');
      emailEl.focus();
      return;
    }

    // FIX: Validate min <= max duration
    const minDur = parseFloat(document.getElementById('setting-min-duration')?.value);
    const maxDur = parseFloat(document.getElementById('setting-max-duration')?.value);
    if (!isNaN(minDur) && !isNaN(maxDur) && minDur > maxDur) {
      showToast('Min Booking Duration cannot exceed Max Booking Duration', 'error');
      return;
    }

    // Save all field values
    const keys = [
      'platform-name', 'support-email', 'contact-phone', 'business-hours',
      'min-duration', 'max-duration', 'advance-booking', 'cancellation-period',
      'platform-fee', 'security-deposit', 'currency', 'timezone', 'date-format',
    ];
    const s = {};
    keys.forEach(k => {
      const el = document.getElementById('setting-' + k);
      if (el) s[k.replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = el.value;
    });
    localStorage.setItem('harvesthub_settings', JSON.stringify(s));
    showToast('Settings saved ✓', 'success');
  }

  reset() {
    showConfirm('Reset all settings to defaults? This cannot be undone.', () => {
      localStorage.removeItem('harvesthub_settings');
      // FIX: Call load() to repopulate fields with defaults.
      // load() calls _bindButtons() which clones buttons, removing any stale listeners.
      this.load();
      showToast('Settings reset to defaults');
    });
  }

  async sendNotification() {
    const title = document.getElementById('notification-title')?.value.trim();
    const message = document.getElementById('notification-message')?.value.trim();

    if (!title || !message) {
      showToast('Title and message are required', 'error');
      return;
    }

    try {
      // Send notification to all users (broadcast)
      await addDoc(collection(db, 'notifications'), {
        title: title,
        message: message,
        isRead: false, // Boolean as required for Android app badge sync
        createdAt: new Date().toISOString(),
        type: 'broadcast' // or 'user' for specific user
      });

      showToast('Notification sent successfully ✓', 'success');
      // Clear fields
      document.getElementById('notification-title').value = '';
      document.getElementById('notification-message').value = '';
    } catch (e) {
      console.error('[SettingsPage] Failed to send notification:', e);
      showToast('Failed to send notification', 'error');
    }
  }
}
