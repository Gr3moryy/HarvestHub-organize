// js/pages/reviews.js
// Fetches reviews from the reviews collection using onSnapshot for real-time updates

import { db } from '../firebase.js';
import {
  showToast, showLoading, hideLoading,
  openModal, closeModal,
} from '../ui.js';
import { esc, cap, debounce } from '../utils.js';
import {
  collection, query, orderBy, limit, onSnapshot,
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js';

export class ReviewsPage {
  constructor() {
    this._data = [];
    this._render = debounce(() => this._renderGrid());
    this._unsubscribers = []; // Store unsubscribe functions for cleanup
  }

  async load() {
    showLoading();
    try {
      // Set up real-time listener for reviews collection
      const reviewsUnsub = onSnapshot(
        query(collection(db, 'reviews'), orderBy('createdAt', 'desc'), limit(50)),
        (snapshot) => {
          this._data = [];
          snapshot.forEach(doc => {
            const data = doc.data();
            // Map Firestore schema to internal format
            const review = {
              id: doc.id,
              rating: data.rating || 0, // number
              content: data.content || '', // string
              userId: data.userId || '',
              userName: data.userName || 'Anonymous',
              harvesterId: data.harvesterId || '',
              harvesterName: data.harvesterName || '',
              createdAt: data.createdAt ? new Date(data.createdAt) : new Date(),
              // Keep original data for compatibility
              _originalData: data
            };
            this._data.push(review);
          });

          this._bindUI();
          this._updateStats();
          this._renderGrid();
        },
        (error) => {
          console.error('[ReviewsPage] Failed to load reviews:', error);
          showToast('Failed to load reviews', 'error');
        }
      );

      this._unsubscribers.push(reviewsUnsub);
    } catch (e) {
      console.error('[ReviewsPage] Failed to set up reviews listener:', e);
      showToast('Failed to load reviews', 'error');
    }
    hideLoading();
  }

  _bindUI() {
    // Add any UI bindings if needed
  }

  _updateStats() {
    const totalReviews = this._data.length;
    const averageRating = totalReviews > 0
      ? (this._data.reduce((sum, r) => sum + r.rating, 0) / totalReviews).toFixed(1)
      : '0.0';

    const set = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };
    set('reviews-total', totalReviews + ' Reviews');
    set('reviews-average', averageRating + ' ★');
  }

  _renderGrid() {
    const grid = document.getElementById('reviews-grid');
    if (!grid) return;

    if (!this._data.length) {
      grid.innerHTML = '<div class="empty-state"><h3>No Reviews Yet</h3><p>Reviews will appear here when users submit feedback.</p></div>';
      return;
    }

    grid.innerHTML = this._data.map(r => this._reviewHTML(r)).join('');
  }

  _reviewHTML(r) {
    const stars = '★'.repeat(Math.floor(r.rating)) + '☆'.repeat(5 - Math.floor(r.rating));
    const dateStr = r.createdAt.toLocaleDateString('en-US', {
      year: 'numeric', month: 'short', day: 'numeric'
    });

    return `<div class="review-card">
      <div class="review-header">
        <div class="review-user">
          <div class="review-avatar">${esc(r.userName.charAt(0).toUpperCase())}</div>
          <div class="review-user-info">
            <div class="review-name">${esc(r.userName)}</div>
            <div class="review-date">${esc(dateStr)}</div>
          </div>
        </div>
        <div class="review-rating">${stars} <span class="rating-number">${r.rating}/5</span></div>
      </div>
      <div class="review-content">${esc(r.content)}</div>
      ${r.harvesterName ? `<div class="review-harvester">For: ${esc(r.harvesterName)}</div>` : ''}
    </div>`;
  }

  // Cleanup method to unsubscribe from all listeners
  destroy() {
    this._unsubscribers.forEach(unsub => unsub());
    this._unsubscribers = [];
  }
}