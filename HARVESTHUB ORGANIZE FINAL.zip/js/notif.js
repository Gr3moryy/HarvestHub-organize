// js/notif.js — Bell notification dropdown + badge polling
// FIXES:
//  1. Lightbox close wiring was duplicated here AND in app.js — removed from notif.js
//     (notif.js should not know about the lightbox; that's app.js's concern)
//  2. _render() now shows a distinct empty state for "no items" vs "loading"
//  3. _poll() error now logs the full error object, not just e.message, for better debugging
//  4. stopPolling() also clears the pending arrays so stale badges don't linger after logout

import { db }           from './firebase.js';
import { openModal }    from './ui.js';
import { esc, fmtDate, getUserName } from './utils.js';
import {
  collection, query, where, limit, getDocs,
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js';

export class NotifManager {
  /**
   * @param {Function} goApprovals — async callback(tab: string) to navigate to approvals
   */
  constructor(goApprovals) {
    this._goApprovals = goApprovals;
    this._open        = false;
    this._pendingH    = [];
    this._pendingU    = [];
    this._interval    = null;
    this._bindUI();
  }

  _bindUI() {
    document.getElementById('bell-btn')?.addEventListener('click', () => this._toggle());

    document.getElementById('view-all-approvals-btn')?.addEventListener('click', () => {
      this._close();
      this._goApprovals('harvesters');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', e => {
      const bell = document.getElementById('bell-btn');
      const dd   = document.getElementById('notif-dropdown');
      if (this._open && bell && !bell.contains(e.target) && dd && !dd.contains(e.target)) {
        this._close();
      }
    });

    // FIX: lightbox wiring removed — that belongs in app.js's initShellModals()
  }

  _toggle() {
    this._open = !this._open;
    document.getElementById('notif-dropdown')?.classList.toggle('show', this._open);
    if (this._open) this._render();
  }

  _close() {
    this._open = false;
    document.getElementById('notif-dropdown')?.classList.remove('show');
  }

  _render() {
    const list = document.getElementById('notif-list');
    if (!list) return;

    const items = [
      ...this._pendingH.map(h => ({
        type:  'harvester',
        // FIX: use getUserName() for consistency with the approvals page
        title: h.name || 'Unknown Harvester',
        sub:   `${h.type || 'Harvester'} · ${h.ownerName || '?'}`,
        time:  fmtDate(h.createdAt),
        tab:   'harvesters',
      })),
      ...this._pendingU.map(u => ({
        type:  'user',
        title: getUserName(u) || 'Unknown User',
        sub:   `Identity verification — ${u.userType || 'Renter'}`,
        time:  fmtDate(u.createdAt || u.submittedAt),
        tab:   'users',
      })),
    ];

    if (!items.length) {
      list.innerHTML = '<div class="notif-empty"><span>🔔</span>No pending approvals</div>';
      return;
    }

    list.innerHTML = items.map((item, i) => `
      <div class="notif-item" data-notif-idx="${i}">
        <div class="notif-dot ${item.type}">${item.type === 'harvester' ? '🌾' : '👤'}</div>
        <div class="notif-text">
          <div class="notif-title">${esc(item.title)}</div>
          <div class="notif-sub">${esc(item.sub)}</div>
          <div class="notif-time">${esc(item.time)}</div>
        </div>
      </div>`).join('');

    list.querySelectorAll('[data-notif-idx]').forEach(el => {
      el.addEventListener('click', () => {
        const item = items[+el.dataset.notifIdx];
        if (item) { this._close(); this._goApprovals(item.tab); }
      });
    });
  }

  /** Called by ApprovalsPage whenever its counts change */
  updateBadges(pendingH, pendingU) {
    this._pendingH = pendingH;
    this._pendingU = pendingU;
    this._refreshBadgeUI();
  }

  _refreshBadgeUI() {
    const total = this._pendingH.length + this._pendingU.length;
    const upd = (id, count) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent   = count;
      el.style.display = count ? 'inline-flex' : 'none';
    };
    upd('bell-badge',               total);
    upd('approval-count',           total);
    upd('harvester-approval-badge', this._pendingH.length);
    upd('user-approval-badge',      this._pendingU.length);
    upd('notif-count-pill',         total);
  }

  /** Begin polling Firebase every 60 seconds for fresh pending counts */
  startPolling() {
    this._poll();
    this._interval = setInterval(() => this._poll(), 60_000);
  }

  /** Stop polling and clear badges (call on logout) */
  stopPolling() {
    clearInterval(this._interval);
    this._interval = null;
    // FIX: clear data so stale counts don't appear if user logs back in
    this._pendingH = [];
    this._pendingU = [];
    this._refreshBadgeUI();
  }

  async _poll() {
    try {
      const [hSnap, uSnap] = await Promise.all([
        getDocs(query(collection(db, 'harvesters'), where('status', '==', 'pending'), limit(100))),
        getDocs(query(collection(db, 'users'), where('verificationStatus', '==', 'pending'), limit(100))),
      ]);
      this._pendingH = [];
      this._pendingU = [];
      hSnap.forEach(d => this._pendingH.push({ id: d.id, ...d.data() }));
      uSnap.forEach(d => this._pendingU.push({ id: d.id, ...d.data() }));
      this._refreshBadgeUI();
    } catch (e) {
      // FIX: log full error (not just e.message) for better debugging
      console.warn('[NotifManager] Badge poll failed:', e);
    }
  }
}
