// js/pages/harvesters.js
// FIXES:
//  1. _save() called load() even on add-new path (which isn't needed since new harvesters
//     go to pending and don't appear in the fleet list). Removed unnecessary reload.
//  2. catch blocks now log the actual error object for better debugging.
//  3. _validate() now reads element values with null safety.
//  4. openEdit() null-checks every getElementById call before accessing properties.

import { db } from '../firebase.js';
import {
  showToast, showLoading, hideLoading,
  openModal, closeModal, showConfirm,
  setFieldError, clearFieldState, showBanner,
  wireLiveValidation, bindModalClose,
} from '../ui.js';
import { esc, cap, debounce, setSelect } from '../utils.js';
import {
  collection, query, where, limit, getDocs,
  updateDoc, deleteDoc, addDoc, doc, onSnapshot,
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js';

export class HarvestersPage {
  constructor() {
    this._data = [];
    this._render = debounce(() => this._renderGrid());
    this._unsubscribers = []; // Store unsubscribe functions for cleanup
  }

  async load() {
    showLoading();
    try {
      // Set up real-time listener for harvesters collection
      const harvestersUnsub = onSnapshot(
        collection(db, 'harvesters'),
        (snapshot) => {
          this._data = [];
          snapshot.forEach(doc => {
            const data = doc.data();
            // Map Android app schema to internal format
            const harvester = {
              id: doc.id,
              // Card title: name field
              name: data.name || 'Unknown Harvester',
              // Sub-title: type field
              type: data.type || 'Harvester',
              // ID: Firestore document ID
              documentId: doc.id,
              // RATE: price field (string like 'PHP 1500/Day')
              price: data.price || 'PHP 0/Day',
              // Extract numeric rate for calculations if needed
              rate: this._extractRate(data.price || 'PHP 0/Day'),
              // YEAR: specs field (model/year info)
              year: data.specs || '-',
              // LOCATION: location field
              location: data.location || '-',
              // IMAGE: imageUrl field
              imageUrl: data.imageUrl || '',
              // Status mapping
              status: this._mapStatus(data.status || 'available'),
              // Raw status for filtering
              rawStatus: data.status || 'available',
              // Keep original data for saving
              _originalData: data
            };
            this._data.push(harvester);
          });

          this._bindUI();
          this._updateStats();
          this._renderGrid();
        },
        (error) => {
          console.error('[HarvestersPage] Failed to load harvesters:', error);
          showToast('Failed to load harvesters', 'error');
        }
      );

      this._unsubscribers.push(harvestersUnsub);
    } catch (e) {
      console.error('[HarvestersPage] Failed to set up harvesters listener:', e);
      showToast('Failed to load harvesters', 'error');
    }
    hideLoading();
  }

  // Extract numeric rate from price string (e.g., 'PHP 1500/Day' -> 1500)
  _extractRate(priceString) {
    const match = priceString.match(/(\d+)/);
    return match ? parseInt(match[1]) : 0;
  }

  // Map Android app status to UI display status
  _mapStatus(status) {
    switch (status) {
      case 'available':
      case 'approved':
        return 'available';
      case 'rented':
        return 'rented';
      case 'under maintenance':
        return 'maintenance';
      default:
        return 'available';
    }
  }

  _bindUI() {
    document.getElementById('harvesterSearch')?.addEventListener('input', this._render);
    document.getElementById('harvesterTypeFilter')?.addEventListener('change', this._render);
    document.getElementById('harvesterStatusFilter')?.addEventListener('change', this._render);
    document.getElementById('hem-save-btn')?.addEventListener('click', () => this._save());
    document.getElementById('hem-delete-btn')?.addEventListener('click', () => this._delete());
    wireLiveValidation([
      ['hem-name',     'err-hem-name'],
      ['hem-year',     'err-hem-year'],
      ['hem-rate',     'err-hem-rate'],
      ['hem-location', 'err-hem-location'],
      ['hem-owner',    'err-hem-owner'],
    ]);
    bindModalClose(document.getElementById('main-content'));
  }

  _updateStats() {
    const countAvailable = this._data.filter(h => h.rawStatus === 'available' || h.rawStatus === 'approved').length;
    const countRented = this._data.filter(h => h.rawStatus === 'rented').length;
    const countMaintenance = this._data.filter(h => h.rawStatus === 'under maintenance').length;

    const set = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };
    set('harvester-available',   countAvailable + ' Available');
    set('harvester-rented',      countRented + ' In Use');
    set('harvester-maintenance', countMaintenance + ' Maintenance');
  }

  _renderGrid() {
    const grid = document.getElementById('harvester-grid');
    if (!grid) return;

    const sq = document.getElementById('harvesterSearch')?.value.toLowerCase()   || '';
    const tf = document.getElementById('harvesterTypeFilter')?.value              || '';
    const sf = document.getElementById('harvesterStatusFilter')?.value            || '';

    const filtered = this._data.filter(h =>
      `${h.name || ''} ${h.type || ''} ${h.location || ''}`.toLowerCase().includes(sq) &&
      (!tf || h.type === tf) &&
      (!sf || h.rawStatus === sf)
    );

    if (!filtered.length) {
      grid.innerHTML = '<div class="empty-state"><h3>No Harvesters Found</h3><p>Try adjusting your filters.</p></div>';
      return;
    }

    grid.innerHTML = filtered.map(h => this._cardHTML(h)).join('');
    grid.querySelectorAll('[data-edit]').forEach(btn =>
      btn.addEventListener('click', () => this.openEdit(btn.dataset.edit))
    );
  }

  _cardHTML(h) {
    const emoji = { 'Combine Harvester': '🌾', 'Rice Harvester': '🌾', 'Corn Harvester': '🌽' };
    const img = h.imageUrl
      ? `<img src="${esc(h.imageUrl)}" alt="${esc(h.name)}" loading="lazy">`
      : `<div class="harvester-image-placeholder">${emoji[h.type] || '🚜'}</div>`;

    // Map status to display text
    const statusDisplay = this._getStatusDisplay(h.rawStatus);

    return `<div class="harvester-card">
      <div class="harvester-image">
        ${img}
        <span class="status-badge ${esc(h.status || 'available')}">${esc(statusDisplay)}</span>
      </div>
      <div class="harvester-info">
        <h3>${esc(h.name || 'Unknown')}</h3>
        <p class="harvester-type">${esc(h.type || '-')}</p>
        <div class="specs">
          <div class="spec-item"><span class="spec-label">ID</span><span class="spec-value">${esc(h.documentId.substring(0, 8))}</span></div>
          <div class="spec-item"><span class="spec-label">Rate</span><span class="spec-value">${esc(h.price)}</span></div>
          <div class="spec-item"><span class="spec-label">Year</span><span class="spec-value">${esc(h.year)}</span></div>
          <div class="spec-item"><span class="spec-label">Location</span><span class="spec-value">${esc(h.location)}</span></div>
        </div>
        <div class="card-actions">
          <button class="btn-action" data-edit="${esc(h.id)}">Edit</button>
        </div>
      </div>
    </div>`;
  }

  // Get display text for status badges
  _getStatusDisplay(rawStatus) {
    switch (rawStatus) {
      case 'available':
      case 'approved':
        return 'Available';
      case 'rented':
        return 'In Use';
      case 'under maintenance':
        return 'Maintenance';
      default:
        return 'Available';
    }
  }

  openEdit(id) {
    const h = this._data.find(x => x.id === id);
    if (!h) return;

    // FIX: null-safe reads on every getElementById
    const setVal = (elId, val) => { const el = document.getElementById(elId); if (el) el.value = val ?? ''; };
    const titleEl = document.getElementById('hem-title');
    if (titleEl) titleEl.textContent = 'Edit Harvester';

    document.getElementById('hem-doc-id').value = id;
    setVal('hem-name',     h.name);
    setVal('hem-year',     h.year); // specs field
    setVal('hem-capacity', ''); // Not used in Android schema
    setVal('hem-rate',     h.rate); // Extracted numeric rate
    setVal('hem-location', h.location);
    setVal('hem-owner',    ''); // Not used in Android schema

    setSelect('hem-type',   h.type   || 'Combine Harvester');
    setSelect('hem-status', h.rawStatus || 'available');

    document.getElementById('hem-status')?.closest('.modal-field')?.style.removeProperty('display');
    const noteEl   = document.getElementById('hem-approval-note');
    const saveBtnEl = document.getElementById('hem-save-btn');
    const delBtnEl  = document.getElementById('hem-delete-btn');
    if (noteEl)    noteEl.style.display    = 'none';
    if (saveBtnEl) saveBtnEl.textContent   = 'Save';
    if (delBtnEl)  delBtnEl.style.display  = 'inline-flex';

    openModal('harvesterEditModal');
  }

  _validate() {
    [
      ['hem-name', 'err-hem-name'], ['hem-year', 'err-hem-year'],
      ['hem-rate', 'err-hem-rate'], ['hem-location', 'err-hem-location'],
    ].forEach(([i, e]) => clearFieldState(i, e));
    showBanner('hem-banner', false);

    let errors = 0;

    const name = document.getElementById('hem-name')?.value.trim() || '';
    if (!name || name.length < 2) {
      const errEl = document.getElementById('err-hem-name');
      if (errEl) errEl.textContent = !name ? 'Name is required' : 'Min 2 characters';
      setFieldError('hem-name', 'err-hem-name', true);
      errors++;
    }

    // Year validation (now used for specs field)
    const yearVal = document.getElementById('hem-year')?.value.trim() || '';
    if (!yearVal) {
      const errEl = document.getElementById('err-hem-year');
      if (errEl) errEl.textContent = 'Year/Model info is required';
      setFieldError('hem-year', 'err-hem-year', true);
      errors++;
    }

    // Rate validation (numeric input, will be converted to price string)
    const rateVal = document.getElementById('hem-rate')?.value.trim() || '';
    const rate = parseFloat(rateVal);
    if (!rateVal) {
      const errEl = document.getElementById('err-hem-rate');
      if (errEl) errEl.textContent = 'Daily rate is required';
      setFieldError('hem-rate', 'err-hem-rate', true);
      errors++;
    } else if (isNaN(rate) || rate < 0) {
      const errEl = document.getElementById('err-hem-rate');
      if (errEl) errEl.textContent = 'Rate must be a positive number';
      setFieldError('hem-rate', 'err-hem-rate', true);
      errors++;
    }

    const location = document.getElementById('hem-location')?.value.trim() || '';
    if (!location) {
      setFieldError('hem-location', 'err-hem-location', true);
      errors++;
    }

    if (errors) showBanner('hem-banner', true);
    return errors === 0;
  }

  async _save() {
    if (!this._validate()) return;

    const id = document.getElementById('hem-doc-id')?.value || '';
    const rate = document.getElementById('hem-rate').value.trim();

    // Convert to Android app schema
    const data = {
      name: document.getElementById('hem-name').value.trim(),
      type: document.getElementById('hem-type').value,
      // Convert numeric rate back to price string format
      price: `PHP ${rate}/Day`,
      // Use specs field for year/model info
      specs: document.getElementById('hem-year').value.trim() || '',
      location: document.getElementById('hem-location').value.trim(),
      // Keep imageUrl if it exists
      ...(this._data.find(h => h.id === id)?.imageUrl && {
        imageUrl: this._data.find(h => h.id === id).imageUrl
      }),
      updatedAt: new Date().toISOString(),
    };

    try {
      if (id) {
        // For updates, include status
        data.status = document.getElementById('hem-status').value;
        await updateDoc(doc(db, 'harvesters', id), data);
        showToast('Harvester updated ✓', 'success');
        closeModal('harvesterEditModal');
        // Data will auto-refresh via onSnapshot
      } else {
        // FIX: New harvesters go to 'pending' — they won't appear in the fleet list.
        // No need to call load() which would show no change and confuse the user.
        data.status = 'pending';
        data.createdAt = new Date().toISOString();
        await addDoc(collection(db, 'harvesters'), data);
        showToast('Submitted for approval ✓', 'success');
        closeModal('harvesterEditModal');
        // Don't reload — new item won't appear here; it shows in the Approvals page.
      }
    } catch (e) {
      console.error('[HarvestersPage] Failed to save harvester:', e);
      showToast('Failed to save harvester', 'error');
    }
  }

  async _delete() {
    const id = document.getElementById('hem-doc-id')?.value || '';
    if (!id) return;
    showConfirm('Delete this harvester permanently? This cannot be undone.', async () => {
      try {
        await deleteDoc(doc(db, 'harvesters', id));
        showToast('Harvester deleted');
        closeModal('harvesterEditModal');
        await this.load();
      } catch (e) {
        console.error('[HarvestersPage] Failed to delete harvester:', e);
        showToast('Delete failed', 'error');
      }
    });
  }

  // Cleanup method to unsubscribe from all listeners
  destroy() {
    this._unsubscribers.forEach(unsub => unsub());
    this._unsubscribers = [];
  }

  /** Called externally after an approval to silently refresh the cache */
  async refreshCache() {
    // With real-time listeners, cache is automatically updated
    // This method is kept for compatibility but no longer needed
    console.log('[HarvestersPage] Cache refresh not needed - using real-time listeners');
  }
}
