// js/firebase.js — Firebase initialisation, shared exports
import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-app.js';
import { getFirestore }  from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js';
import { getAuth }       from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js';

const firebaseConfig = {
  apiKey:            "AIzaSyDE4oLipbxiVtb4PtTVdcXsQaJO6wxSkF0",
  authDomain:        "harvesthub-25071.firebaseapp.com",
  projectId:         "harvesthub-25071",
  storageBucket:     "harvesthub-25071.firebasestorage.app",
  messagingSenderId: "727328652891",
  appId:             "1:727328652891:web:76b8fe7fe3f55c5040097e",
};

const firebaseApp = initializeApp(firebaseConfig);

export const db   = getFirestore(firebaseApp);
export const auth = getAuth(firebaseApp);

/** Returns true if the given user has admin privileges */
export function isAdmin(user) {
  return user && (
    user.email?.endsWith('@harvesthub.com') ||
    user.uid === '3YLY0Mg1fxU1kV5f2TZzZm9ga1h2'
  );
}
