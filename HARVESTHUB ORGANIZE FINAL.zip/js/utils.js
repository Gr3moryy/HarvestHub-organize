// js/utils.js — Pure utility helpers, no DOM, no Firebase
// FIXES:
//  1. fmtDate() returned 'Invalid Date' for null/undefined — now returns '-'
//  2. initials() crashed with 'Cannot read properties of undefined' when a word
//     was empty string (e.g. double space in name) — added filter for truthy words
//  3. avatarColor() crashed when id was null — already guarded but made explicit
//  4. getImageUrl() 'selfie' map included 'selfie' key which would match any field
//     literally named 'selfie' that contains a non-URL value — added URL validation

/** Escape a string for safe HTML insertion */
export function esc(str) {
  return String(str ?? '')
    .replace(/&/g,  '&amp;')
    .replace(/</g,  '&lt;')
    .replace(/>/g,  '&gt;')
    .replace(/"/g,  '&quot;')
    .replace(/'/g,  '&#39;');
}

/** Format any date-like value to "Jan 1, 2025". Returns '-' for invalid/null values. */
export function fmtDate(d) {
  // FIX: explicit null/undefined guard before attempting Date construction
  if (d == null || d === '') return '-';
  try {
    const date = new Date(d);
    // FIX: check for Invalid Date before calling toLocaleDateString
    if (isNaN(date.getTime())) return '-';
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch {
    return '-';
  }
}

/** Capitalise the first letter of a string */
export const cap = s => (s ? s.charAt(0).toUpperCase() + s.slice(1) : '');

/** Set a <select> element to the option matching value or text */
export function setSelect(id, val) {
  const el = document.getElementById(id);
  if (!el) return;
  for (const o of el.options) {
    if (o.value === val || o.text === val) { o.selected = true; return; }
  }
}

/** Returns a debounced version of fn that fires after ms milliseconds of inactivity */
export function debounce(fn, ms = 300) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

/** Format a date-of-birth value to MM/DD/YYYY */
export function formatDob(dob) {
  if (!dob) return 'Not provided';
  try {
    const d = new Date(dob);
    if (isNaN(d.getTime())) return 'Not provided';
    return `${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}/${d.getFullYear()}`;
  } catch {
    return 'Not provided';
  }
}

/** Resolve the first non-empty string value from a list of possible keys on obj */
export function resolveField(obj, keys) {
  for (const k of keys) {
    if (obj[k] && typeof obj[k] === 'string' && obj[k].trim()) return obj[k].trim();
  }
  return null;
}

export const getUserName = obj =>
  resolveField(obj, ['name', 'fullName', 'full_name', 'fullname', 'displayName', 'display_name']) ||
  [obj.firstName || obj.first_name || '', obj.lastName || obj.last_name || ''].join(' ').trim() ||
  null;

export const getUserEmail = obj =>
  resolveField(obj, ['email', 'userEmail', 'user_email', 'emailAddress', 'email_address', 'mail']);

export const getUserPhone = obj =>
  resolveField(obj, ['phone', 'phoneNumber', 'phone_number', 'mobile', 'mobileNumber', 'tel']);

/** Try several field-name patterns to find an image URL for a given type */
export function getImageUrl(obj, type) {
  const maps = {
    idFront: ['idFrontUrl','id_front_url','frontIdUrl','idImageFront','id_image_front','idCardFront','governmentIdFront','frontIdCard'],
    idBack:  ['idBackUrl','id_back_url','backIdUrl','idImageBack','id_image_back','idCardBack','governmentIdBack','backIdCard'],
    selfie:  ['selfieUrl','selfie_url','selfieImageUrl','selfiePhotoUrl','selfie_photo_url','photoUrl','photo_url','userPhotoUrl','profilePhotoUrl','verificationSelfieUrl'],
  };
  for (const k of (maps[type] || [])) {
    const val = obj[k];
    // FIX: validate it's actually a URL string, not just any truthy value
    if (val && typeof val === 'string' && (val.startsWith('http') || val.startsWith('/'))) return val;
  }
  return null;
}

/**
 * Get 1–2 initials from a display name.
 * FIX: filter out empty words so double spaces or leading spaces don't produce undefined[0]
 */
export function initials(name) {
  if (!name) return '?';
  return (name.split(' ').filter(Boolean).map(w => w[0]).join('').substring(0, 2).toUpperCase()) || '?';
}

export const AVATAR_COLORS = ['#2d7a2d', '#1a6aaa', '#8a3a1a', '#6a1a8a', '#1a5a5a', '#8a5a1a'];

/** Get a deterministic avatar colour from a user ID string */
export function avatarColor(id) {
  // FIX: explicit null guard — charCodeAt(0) on null/undefined throws
  if (!id) return AVATAR_COLORS[0];
  return AVATAR_COLORS[id.charCodeAt(0) % AVATAR_COLORS.length];
}

/** Animate a numeric stat counter from 0 to target */
export function animateCount(el, target) {
  if (!el) return;
  if (el.dataset.animating === 'true') return;
  el.dataset.animating = 'true';
  const dur = 900, startTime = performance.now(), ease = t => 1 - (1 - t) ** 3;
  const step = now => {
    const p = Math.min((now - startTime) / dur, 1);
    el.textContent = Math.round(ease(p) * target);
    if (p < 1) requestAnimationFrame(step);
    else el.dataset.animating = 'false';
  };
  requestAnimationFrame(step);
}
