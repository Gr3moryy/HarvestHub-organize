// js/auth.js — Loaded only by index.html (login page)
// FIXES:
//  1. ForgotPasswordModal.open() used el.value='' on <div> elements (no-op) → fixed to textContent=''
//  2. Added _submitting guard to prevent double-submit
//  3. Enter key now ignores when forgot-password modal is open
//  4. Added more Firebase auth error codes (wrong-password, user-not-found, network-request-failed)
//  5. bindModalClose() explicitly passes `document` to wire ALL overlays and [data-close] buttons

import { auth, isAdmin } from './firebase.js';
import { openModal, bindModalClose } from './ui.js';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js';

// ── Auth State: redirect if already logged in ─────────────────────────────────
onAuthStateChanged(auth, user => {
  if (user && isAdmin(user)) {
    window.location.href = 'pages/shell.html';
  }
});

// ── Login Form ────────────────────────────────────────────────────────────────
class LoginForm {
  constructor() {
    this._btn        = document.getElementById('login-btn');
    this._emailEl    = document.getElementById('loginUsername');
    this._passEl     = document.getElementById('loginPassword');
    this._errBanner  = document.getElementById('loginError');
    this._submitting = false;

    this._btn.addEventListener('click', () => this.submit());

    // FIX: only fire Enter when the forgot-password modal is NOT open
    document.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !document.getElementById('forgotPasswordModal')?.classList.contains('open')) {
        this.submit();
      }
    });

    this._emailEl.addEventListener('input', () => this._clearField('loginUsername', 'err-login-email'));
    this._passEl.addEventListener('input',  () => this._clearField('loginPassword', 'err-login-pass'));
  }

  async submit() {
    if (this._submitting) return; // FIX: prevent double-submit

    const email = this._emailEl.value.trim();
    const pass  = this._passEl.value;
    this._hideBanner();
    this._clearAll();

    let hasErr = false;
    if (!email) {
      this._fieldErr('loginUsername', 'err-login-email', 'Email is required.');
      hasErr = true;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      this._fieldErr('loginUsername', 'err-login-email', 'Enter a valid email address.');
      hasErr = true;
    }
    if (!pass) {
      this._fieldErr('loginPassword', 'err-login-pass', 'Password is required.');
      hasErr = true;
    } else if (pass.length < 6) {
      this._fieldErr('loginPassword', 'err-login-pass', 'Password must be at least 6 characters.');
      hasErr = true;
    }
    if (hasErr) return;

    this._setLoading(true);
    try {
console.log('Attempting signIn with', email); const cred = await signInWithEmailAndPassword(auth, email, pass); console.log('signIn result:', cred.user?.email, 'isAdmin:', isAdmin(cred.user));
      if (!isAdmin(cred.user)) {
        await signOut(auth);
        this._showBanner('Access denied. This portal is for admin accounts only.');
        return;
      }
      // onAuthStateChanged handles the redirect
    } catch (e) {
      const msgs = {
        'auth/invalid-credential':     'Incorrect email or password.',
        'auth/wrong-password':         'Incorrect email or password.',
        'auth/user-not-found':         'No account found with that email.',
        'auth/too-many-requests':      'Too many failed attempts. Try again later.',
        'auth/network-request-failed': 'Network error. Check your connection.',
        'auth/user-disabled':          'This account has been disabled.',
        'auth/invalid-email':          'Invalid email address format.',
      };
      document.getElementById('loginUsername')?.classList.add('input-error');
      document.getElementById('loginPassword')?.classList.add('input-error');
      this._showBanner(msgs[e.code] || 'Login failed. Please try again.');
    } finally {
      this._setLoading(false);
    }
  }

  _setLoading(on) {
    this._submitting      = on;
    this._btn.textContent = on ? 'Logging in…' : 'Log In';
    this._btn.disabled    = on;
  }

  _fieldErr(inputId, errId, msg) {
    document.getElementById(inputId)?.classList.add('input-error');
    const er = document.getElementById(errId);
    if (er && msg?.trim()) { er.textContent = msg; er.classList.add('show'); }
  }

  _clearField(inputId, errId) {
    document.getElementById(inputId)?.classList.remove('input-error');
    const er = document.getElementById(errId);
    if (er) { er.textContent = ''; er.classList.remove('show'); }
    this._hideBanner();
  }

  _clearAll() {
    ['loginUsername', 'loginPassword'].forEach(id =>
      document.getElementById(id)?.classList.remove('input-error')
    );
    ['err-login-email', 'err-login-pass'].forEach(id => {
      const el = document.getElementById(id);
      if (el) { el.textContent = ''; el.classList.remove('show'); }
    });
  }

  _showBanner(msg) {
    this._errBanner.textContent   = msg;
    this._errBanner.style.display = 'block';
  }

  _hideBanner() {
    this._errBanner.style.display = 'none';
  }
}

// ── Forgot Password Modal ─────────────────────────────────────────────────────
class ForgotPasswordModal {
  constructor() {
document.getElementById('forgot-pw-btn')?.addEventListener('click', () => { console.log('Forgot PW button clicked'); this.open(); });
    document.getElementById('send-reset-btn')?.addEventListener('click', () => this.send());
    // FIX: pass document explicitly so all .modal-overlay and [data-close] buttons are wired
    bindModalClose(document);
  }

open() { console.log('Opening forgot modal'); const modalEl = document.getElementById('forgotPasswordModal');
    const emailEl   = document.getElementById('forgot-email');
    const successEl = document.getElementById('forgot-success');
    const errorEl   = document.getElementById('forgot-error');

    if (emailEl)   { emailEl.value = ''; emailEl.classList.remove('input-error'); }
    // FIX: successEl and errorEl are <div>s — must use textContent, not .value
    if (successEl) { successEl.textContent = ''; successEl.style.display = 'none'; }
    if (errorEl)   { errorEl.textContent   = ''; errorEl.style.display   = 'none'; }

    openModal('forgotPasswordModal');
  }

  async send() {
    const emailEl = document.getElementById('forgot-email');
    const errEl   = document.getElementById('forgot-error');
    const okEl    = document.getElementById('forgot-success');
    const btn     = document.getElementById('send-reset-btn');
    if (!emailEl) return;

    const email = emailEl.value.trim();

    // Reset state
    errEl.textContent = ''; errEl.style.display = 'none';
    okEl.textContent  = ''; okEl.style.display  = 'none';
    emailEl.classList.remove('input-error');

    if (!email) {
      emailEl.classList.add('input-error');
      errEl.textContent   = 'Please enter your email address.';
      errEl.style.display = 'block';
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      emailEl.classList.add('input-error');
      errEl.textContent   = 'Enter a valid email address.';
      errEl.style.display = 'block';
      return;
    }

    btn.textContent = 'Sending…';
    btn.disabled    = true;
    try {
      await sendPasswordResetEmail(auth, email);
      // FIX: use textContent on the <div>, not .value
      okEl.textContent   = '✓ Password reset email sent! Check your inbox.';
      okEl.style.display = 'block';
      emailEl.value = '';
    } catch (e) {
      emailEl.classList.add('input-error');
      const msgs = {
        'auth/user-not-found':         'No account found with that email address.',
        'auth/invalid-email':          'Invalid email address format.',
        'auth/too-many-requests':      'Too many requests. Please wait and try again.',
        'auth/network-request-failed': 'Network error. Check your connection.',
      };
      errEl.textContent   = msgs[e.code] || 'Failed to send reset email. Please try again.';
      errEl.style.display = 'block';
    } finally {
      btn.textContent = 'Send Reset Link';
      btn.disabled    = false;
    }
  }
}

console.log('auth.js loaded, init LoginForm and ForgotPasswordModal'); // ── Boot ──────────────────────────────────────────────────────────────────────
new LoginForm();
new ForgotPasswordModal();
