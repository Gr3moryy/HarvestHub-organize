// js/pages/customers.js
// FIXES:
//  1. Renter count filter used strict equality `c.userType==='Renter'` but Firebase data
//     may store it as 'renter' (lowercase). Fixed by case-insensitive comparison.
//  2. Added proper console.error logging in catch blocks for easier debugging.
//  3. _save() now catches and logs the specific Firebase error instead of swallowing it.

import { db } from '../firebase.js';
import {
  showToast, showLoading, hideLoading,
  openModal, closeModal, showConfirm,
  setFieldError, clearFieldState, showBanner,
  wireLiveValidation, bindModalClose,
} from '../ui.js';
import { esc, cap, debounce, setSelect, initials, avatarColor } from '../utils.js';
import {
  collection, query, limit, getDocs,
  updateDoc, deleteDoc, addDoc, doc,
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js';

export class CustomersPage {
  constructor() {
    this._data   = [];
    this._render = debounce(() => this._renderGrid());
  }

  async load() {
    showLoading();
    try {
      this._data = [];
      const snap = await getDocs(query(collection(db, 'users'), limit(25)));
      snap.forEach(d => {
        const data = d.data();
        // Map Firestore schema to internal format
        const user = {
          id: d.id,
          // Name: prioritize fullName, fallback to firstName + lastName
          name: data.fullName || (data.firstName && data.lastName ? `${data.firstName} ${data.lastName}` : 'Unknown'),
          firstName: data.firstName || '',
          lastName: data.lastName || '',
          fullName: data.fullName || '',
          email: data.email || '',
          // Phone: use mobile field
          phone: data.mobile || '',
          // Location: prioritize location, fallback to permanentAddress or address
          location: data.location || data.permanentAddress || data.address || '',
          // Role: map to userType for backward compatibility
          userType: data.role || 'user',
          role: data.role || 'user',
          status: data.status || 'Active',
          profileImage: data.profileImage || '',
          // Keep original data for saving
          _originalData: data
        };
        this._data.push(user);
      });
      this._bindUI();
      this._renderGrid();
    } catch (e) {
      console.error('[CustomersPage] Failed to load users:', e);
      showToast('Failed to load users', 'error');
    }
    hideLoading();
  }

  _bindUI() {
    document.getElementById('customerSearch')?.addEventListener('input', this._render);
    document.getElementById('customerTypeFilter')?.addEventListener('change', this._render);
    document.getElementById('customerStatusFilter')?.addEventListener('change', this._render);
    document.getElementById('cem-save-btn')?.addEventListener('click', () => this._save());
    document.getElementById('cem-delete-btn')?.addEventListener('click', () => this._delete());
    wireLiveValidation([
      ['cem-name',  'err-cem-name'],
      ['cem-email', 'err-cem-email'],
      ['cem-phone', 'err-cem-phone'],
    ]);
    bindModalClose(document.getElementById('main-content'));
  }

  _renderGrid() {
    const grid  = document.getElementById('user-card-grid');
    const empty = document.getElementById('user-empty');
    if (!grid) return;

    const sq = document.getElementById('customerSearch')?.value.toLowerCase() || '';
    const tf = document.getElementById('customerTypeFilter')?.value  || '';
    const sf = document.getElementById('customerStatusFilter')?.value || '';

    const filtered = this._data.filter(c =>
      `${c.name || ''} ${c.email || ''}`.toLowerCase().includes(sq) &&
      // Use role field for filtering
      (!tf || (c.role || '').toLowerCase() === tf.toLowerCase()) &&
      (!sf || (c.status   || 'Active') === sf)
    );

    // Summary chips
    const set = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };
    const normalise = v => (v || '').toLowerCase();
    set('chip-total-users',  this._data.length + ' Total');
    set('chip-active-users', this._data.filter(c => (c.status || 'Active') === 'Active').length + ' Active');
    // Use role field for owner/user counts
    set('chip-owners',  this._data.filter(c => normalise(c.role) === 'owner').length  + ' Owners');
    set('chip-renters', this._data.filter(c => normalise(c.role) === 'user' || !c.role).length + ' Users');

    if (!filtered.length) {
      grid.innerHTML = '';
      if (empty) empty.style.display = 'flex';
      return;
    }
    if (empty) empty.style.display = 'none';

    grid.innerHTML = filtered.map(c => {
      const color   = avatarColor(c.id);
      const ini     = initials(c.name);
      // Use role instead of userType for display
      const roleKey = (c.role || 'user').toLowerCase();
      const stKey   = (c.status || 'active').toLowerCase();
      const vKey    = c.verificationStatus === 'verified' ? 'verified'
                    : c.verificationStatus === 'pending'  ? 'pending' : '';
      return `<div class="u-card">
        <div class="u-avatar" style="background:${color}">${esc(ini)}</div>
        <div class="u-info">
          <div class="u-name">${esc(c.name || 'Unknown')}</div>
          <div class="u-email">${esc(c.email || '-')}</div>
          <div class="u-tags">
            <span class="u-tag ${roleKey}">${esc(cap(c.role || 'user'))}</span>
            <span class="u-tag ${stKey}">${cap(c.status || 'Active')}</span>
            ${vKey ? `<span class="u-tag ${vKey}">${cap(vKey)}</span>` : ''}
          </div>
        </div>
        <div class="u-right">
          <button class="u-edit-btn" data-edit="${esc(c.id)}">Edit</button>
          ${c.location ? `<span class="u-location">📍 ${esc(c.location)}</span>` : ''}
        </div>
      </div>`;
    }).join('');

    grid.querySelectorAll('[data-edit]').forEach(btn =>
      btn.addEventListener('click', () => this.openEdit(btn.dataset.edit))
    );
  }

  openEdit(id) {
    const c = this._data.find(x => x.id === id);
    if (!c) return;
    document.getElementById('cem-doc-id').value   = id;
    document.getElementById('cem-name').value     = c.name     || '';
    document.getElementById('cem-email').value    = c.email    || '';
    // Use mobile field for phone
    document.getElementById('cem-phone').value    = c.phone    || '';
    document.getElementById('cem-location').value = c.location || '';
    // Use role field for type selection
    setSelect('cem-type',   c.role || 'user');
    setSelect('cem-status', c.status   || 'Active');
    document.getElementById('cem-delete-btn').style.display = 'inline-flex';
    openModal('customerEditModal');
  }

  _validate() {
    [['cem-name', 'err-cem-name'], ['cem-email', 'err-cem-email'], ['cem-phone', 'err-cem-phone']]
      .forEach(([i, e]) => clearFieldState(i, e));
    showBanner('cem-banner', false);

    let errors = 0;
    const name = document.getElementById('cem-name')?.value.trim() || '';
    if (!name || name.length < 2) {
      const errEl = document.getElementById('err-cem-name');
      if (errEl) errEl.textContent = !name ? 'Name is required' : 'Min 2 characters';
      setFieldError('cem-name', 'err-cem-name', true);
      errors++;
    }

    const email = document.getElementById('cem-email')?.value.trim() || '';
    if (!email) {
      const errEl = document.getElementById('err-cem-email');
      if (errEl) errEl.textContent = 'Email is required';
      setFieldError('cem-email', 'err-cem-email', true);
      errors++;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      const errEl = document.getElementById('err-cem-email');
      if (errEl) errEl.textContent = 'Enter a valid email address';
      setFieldError('cem-email', 'err-cem-email', true);
      errors++;
    }

    const phone = document.getElementById('cem-phone')?.value.trim() || '';
    if (phone && !/^[+\d\s\-().]{7,20}$/.test(phone)) {
      const errEl = document.getElementById('err-cem-phone');
      if (errEl) errEl.textContent = 'Enter a valid phone number';
      setFieldError('cem-phone', 'err-cem-phone', true);
      errors++;
    }

    if (errors) showBanner('cem-banner', true);
    return errors === 0;
  }

  async _save() {
    if (!this._validate()) return;
    const id = document.getElementById('cem-doc-id')?.value || '';
    const name = document.getElementById('cem-name').value.trim();
    // Split name into first and last name
    const nameParts = name.split(' ');
    const firstName = nameParts[0] || '';
    const lastName = nameParts.slice(1).join(' ') || '';

    const data = {
      firstName: firstName,
      lastName: lastName,
      fullName: name,
      email:     document.getElementById('cem-email').value.trim(),
      mobile:    document.getElementById('cem-phone').value.trim(),
      location:  document.getElementById('cem-location').value.trim(),
      role:      document.getElementById('cem-type').value,
      status:    document.getElementById('cem-status').value,
      updatedAt: new Date().toISOString(),
    };
    try {
      if (id) {
        await updateDoc(doc(db, 'users', id), data);
        showToast('User updated ✓', 'success');
      } else {
        await addDoc(collection(db, 'users'), { ...data, createdAt: new Date().toISOString() });
        showToast('User added ✓', 'success');
      }
      closeModal('customerEditModal');
      await this.load();
    } catch (e) {
      console.error('[CustomersPage] Failed to save user:', e);
      showToast('Failed to save user', 'error');
    }
  }

  async _delete() {
    const id   = document.getElementById('cem-doc-id')?.value || '';
    if (!id) return;
    const name = document.getElementById('cem-name')?.value || 'this user';
    showConfirm(`Permanently delete "${name}"? This cannot be undone.`, async () => {
      try {
        // Call the server-side API to delete from both Auth and Firestore
        const response = await fetch(`/api/users/${id}`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json'
          }
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.error || 'Failed to delete user');
        }

        const result = await response.json();
        showToast(result.message || 'User deleted successfully');
        closeModal('customerEditModal');
        this._data = this._data.filter(c => c.id !== id);
        this._renderGrid();
      } catch (e) {
        console.error('[CustomersPage] Failed to delete user:', e);
        showToast('Delete failed: ' + e.message, 'error');
      }
    });
  }
}
