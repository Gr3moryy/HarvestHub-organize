// js/pages/dashboard.js
// FIXES:
//  1. new Date(b.startDate) / new Date(b.endDate) could produce Invalid Date if the
//     Firestore field is a Timestamp object (not a string). Added .toDate() handling.
//  2. Math.ceil((e - s) / 86400000) in upcoming table could produce NaN if either date
//     is invalid — added isNaN guard.
//  3. Errors in _loadCurrentRentals and _loadUpcoming are now logged properly.

import { db } from '../firebase.js';
import { showToast, showLoading, hideLoading } from '../ui.js';
import { fmtDate, esc, animateCount } from '../utils.js';
import {
  collection, query, where, getDocs, orderBy, limit, getCountFromServer, onSnapshot,
  doc, getDoc
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js';

/** Convert a Firestore field value to a JS Date
 * Handles: Firestore Timestamp, Long (milliseconds), or string dates
 */
function toDate(val) {
  if (!val) return new Date(NaN);

  // Firestore Timestamp objects have a .toDate() method
  if (typeof val.toDate === 'function') return val.toDate();

  // Handle Long timestamps (milliseconds from Android)
  if (typeof val === 'number' && val > 1000000000000) { // timestamps after 2001
    return new Date(val);
  }

  // Handle string dates
  if (typeof val === 'string') return new Date(val);

  return new Date(NaN);
}

export class DashboardPage {
  constructor() {
    this._unsubscribers = []; // Store unsubscribe functions for cleanup
  }

  async load() {
    showLoading();
    try {
      // Set up real-time listeners for metrics
      this._setupMetricsListeners();

      // Load initial table data
      await Promise.all([this._loadCurrentRentals(), this._loadUpcoming()]);
    } catch (e) {
      console.error('[DashboardPage] Failed to load dashboard:', e);
      showToast('Failed to load dashboard', 'error');
    }
    hideLoading();
  }

  _setupMetricsListeners() {
    const now = new Date();

    // 1. Total Bookings: Count all documents in rentals collection
    const totalBookingsUnsub = onSnapshot(collection(db, 'rentals'), (snapshot) => {
      this._setStat('stat-total-bookings', snapshot.size);
    });
    this._unsubscribers.push(totalBookingsUnsub);

    // 2. Active Rentals: rentals where status == 'active' AND current date between startDate and endDate
    const activeRentalsUnsub = onSnapshot(
      query(collection(db, 'rentals'), where('status', '==', 'active')),
      (snapshot) => {
        const now = Date.now();
        let activeCount = 0;
        snapshot.forEach(doc => {
          const data = doc.data();
          if (data.startDate <= now && data.endDate >= now) {
            activeCount++;
          }
        });
        this._setStat('stat-active-rentals', activeCount);
      }
    );
    this._unsubscribers.push(activeRentalsUnsub);

    // 3. Harvesters Available: harvesters where status == 'available' or status == 'approved'
    const harvestersUnsub = onSnapshot(
      query(collection(db, 'harvesters'), where('status', 'in', ['available', 'approved'])),
      (snapshot) => {
        this._setStat('stat-available-harvesters', snapshot.size);
      }
    );
    this._unsubscribers.push(harvestersUnsub);

    // 4. Upcoming Services: rentals where status == 'active' AND startDate > current time
    const upcomingServicesUnsub = onSnapshot(
      query(collection(db, 'rentals'), where('status', '==', 'active')),
      (snapshot) => {
        const now = Date.now();
        let upcomingCount = 0;
        snapshot.forEach(doc => {
          const data = doc.data();
          if (data.startDate > now) {
            upcomingCount++;
          }
        });
        this._setStat('stat-upcoming-services', upcomingCount);
      }
    );
    this._unsubscribers.push(upcomingServicesUnsub);
  }

  // Cleanup method to unsubscribe from all listeners
  destroy() {
    this._unsubscribers.forEach(unsub => unsub());
    this._unsubscribers = [];
  }

  _setStat(id, val) {
    const el = document.getElementById(id);
    if (!el) return;
    if (el.hasAttribute('data-count') && typeof val === 'number') animateCount(el, val);
    else el.textContent = val;
  }

  async _loadCurrentRentals() {
    const tb = document.getElementById('current-rentals-tbody');
    if (!tb) return;

    // Set up real-time listener for active rentals
    const rentalsUnsub = onSnapshot(
      query(collection(db, 'rentals'), where('status', '==', 'active')),
      async (snapshot) => {
        const now = Date.now();
        const rentals = [];

        // Collect rentals that are currently active
        snapshot.forEach(doc => {
          const data = doc.data();
          if (data.startDate <= now && data.endDate >= now) {
            rentals.push({
              id: doc.id,
              ...data,
              startDate: data.startDate,
              endDate: data.endDate
            });
          }
        });

        // Sort by start date and take first 5
        rentals.sort((a, b) => a.startDate - b.startDate);
        const displayRentals = rentals.slice(0, 5);

        if (displayRentals.length === 0) {
          tb.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#9aaa9a;padding:20px">No active rentals</td></tr>';
          return;
        }

        // Build rows with location fallback
        const rows = await Promise.all(displayRentals.map(async (rental) => {
          let location = rental.location || '';

          // If no location in rental, try to get from harvester
          if (!location && rental.harvesterId) {
            try {
              const harvesterDoc = await getDoc(doc(db, 'harvesters', rental.harvesterId));
              if (harvesterDoc.exists()) {
                location = harvesterDoc.data().location || '';
              }
            } catch (e) {
              console.warn(`Failed to fetch harvester location for ${rental.harvesterId}:`, e);
            }
          }

          // Format date range
          const startStr = new Date(rental.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
          const endStr = new Date(rental.endDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
          const period = `${startStr} - ${endStr}`;

          return `<tr>
            <td>${esc(rental.renterName || '-')}</td>
            <td>${esc(rental.harvesterName || '-')}</td>
            <td>${esc(location || '-')}</td>
            <td>${esc(period)}</td>
          </tr>`;
        }));

        tb.innerHTML = rows.join('');
      },
      (error) => {
        console.error('[DashboardPage] Failed to load current rentals:', error);
        tb.innerHTML = '<tr><td colspan="4">Error loading rentals</td></tr>';
      }
    );

    this._unsubscribers.push(rentalsUnsub);
  }

  async _loadUpcoming() {
    const tb = document.getElementById('upcoming-bookings-tbody');
    if (!tb) return;

    // Set up real-time listener for upcoming bookings
    const upcomingUnsub = onSnapshot(
      query(collection(db, 'rentals'), where('status', '==', 'active'), orderBy('startDate', 'asc')),
      (snapshot) => {
        const now = Date.now();
        const upcomingBookings = [];

        snapshot.forEach(doc => {
          const data = doc.data();
          const startDate = data.startDate;
          const endDate = data.endDate;

          // Only include bookings that start in the future
          if (startDate > now) {
            upcomingBookings.push({
              id: doc.id,
              ...data,
              startDate,
              endDate
            });
          }
        });

        // Take first 5 upcoming bookings
        const displayBookings = upcomingBookings.slice(0, 5);

        if (displayBookings.length === 0) {
          tb.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#9aaa9a;padding:20px">No upcoming bookings</td></tr>';
          return;
        }

        const rows = displayBookings.map(booking => {
          // Calculate duration in days
          const durationMs = booking.endDate - booking.startDate;
          const durationDays = Math.ceil(durationMs / (1000 * 60 * 60 * 24));
          const durationStr = isNaN(durationDays) ? '?' : `${durationDays}d`;

          // Format start date
          const startStr = new Date(booking.startDate).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
          });

          return `<tr>
            <td>${esc(booking.renterName || '-')}</td>
            <td>${esc(booking.harvesterName || '-')}</td>
            <td>${esc(startStr)}</td>
            <td>${esc(durationStr)}</td>
          </tr>`;
        });

        tb.innerHTML = rows.join('');
      },
      (error) => {
        console.error('[DashboardPage] Failed to load upcoming bookings:', error);
        tb.innerHTML = '<tr><td colspan="4">Error loading bookings</td></tr>';
      }
    );

    this._unsubscribers.push(upcomingUnsub);
  }
}
