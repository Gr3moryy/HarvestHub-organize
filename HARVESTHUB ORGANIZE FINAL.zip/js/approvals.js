// js/pages/approvals.js
// FIXES:
//  1. _loadUsers() filter bug: (!vs && !st) incorrectly included ALL users that had no
//     verificationStatus field (i.e. normal active users). Fixed to only include users
//     where verificationStatus === 'pending' OR status === 'pending'.
//  2. _bindTabUI() added an idempotency guard so re-calling it (e.g. after a tab switch
//     that re-invokes load()) doesn't stack duplicate event listeners on the same elements.
//  3. _openRejectH: added null check so it doesn't crash if rejection-reason is missing.
//  4. switchTab: titles now use 'approvals-page-title' which may not exist if page not loaded — 
//     added null safety.
//  5. Error objects in catch blocks now logged properly (was empty catch {}).

import { db } from '../firebase.js';
import {
  showToast, showLoading, hideLoading,
  openModal, closeModal,
  setFieldError, clearFieldState, wireLiveValidation,
  attachCharCounter, bindModalClose,
} from '../ui.js';
import {
  esc, cap, debounce, fmtDate, formatDob,
  getUserName, getUserEmail, getUserPhone,
  getImageUrl, initials, avatarColor,
} from '../utils.js';
import {
  collection, query, where, limit, getDocs, getDoc,
  updateDoc, doc,
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js';

export class ApprovalsPage {
  /**
   * @param {Function} onBadgeUpdate — called with (pendingH[], pendingU[]) on every count change
   */
  constructor(onBadgeUpdate) {
    this._onBadgeUpdate = onBadgeUpdate;
    this._pendingH      = [];
    this._pendingU      = [];
    this._currentTab    = 'harvesters';
    this._renderH       = debounce(() => this._renderHarvesters());
    this._renderU       = debounce(() => this._renderUsers());
    this._uiBound       = false; // FIX: idempotency flag for _bindTabUI
  }

  /** Load the page into #main-content, optionally switching to a specific tab */
  async load(tab) {
    if (tab) this._currentTab = tab;
    this._uiBound = false;  // reset so _bindTabUI wires the freshly-injected HTML
    this._bindTabUI();
    if (this._currentTab === 'users') await this._loadUsers();
    else                              await this._loadHarvesters();
  }

  // FIX: guard so this method never wires the same elements twice
  _bindTabUI() {
    if (this._uiBound) return;
    this._uiBound = true;

    document.getElementById('approvalSearch')?.addEventListener('input', this._renderH);
    document.getElementById('approvalTypeFilter')?.addEventListener('change', this._renderH);
    document.getElementById('userApprovalSearch')?.addEventListener('input', this._renderU);
    document.getElementById('userApprovalTypeFilter')?.addEventListener('change', this._renderU);

    document.getElementById('confirm-reject-btn')?.addEventListener('click', () => this._confirmRejectH());
    document.getElementById('confirm-reject-user-btn')?.addEventListener('click', () => this._confirmRejectU());

    attachCharCounter('rejection-reason', 500);
    attachCharCounter('user-rejection-reason', 500);
    wireLiveValidation([
      ['rejection-reason',      'err-rejection-reason'],
      ['user-rejection-reason', 'err-user-rejection-reason'],
    ]);
    bindModalClose(document.getElementById('main-content'));
  }

  // ── Harvester Approvals ────────────────────────────────────────────────────

  async _loadHarvesters() {
    showLoading();
    const grid  = document.getElementById('approval-grid');
    const empty = document.getElementById('approval-empty');
    if (grid)  grid.innerHTML      = '';
    if (empty) empty.style.display = 'none';
    try {
      const snap = await getDocs(query(
        collection(db, 'harvesters'), where('status', '==', 'pending'), limit(25),
      ));
      this._pendingH = [];
      snap.forEach(d => this._pendingH.push({ id: d.id, ...d.data() }));
      this._updateHStats();
      this._renderHarvesters();
      this._syncBadges();
    } catch (e) {
      console.error('[ApprovalsPage] Failed to load harvester approvals:', e);
      showToast('Failed to load approvals', 'error');
    }
    hideLoading();
  }

  _updateHStats() {
    const set = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };
    set('pending-count',  this._pendingH.length + ' Pending');
    set('approved-count', '— Approved Today');
    set('rejected-count', '— Rejected Today');
  }

  _renderHarvesters() {
    const grid  = document.getElementById('approval-grid');
    const empty = document.getElementById('approval-empty');
    if (!grid) return;

    const sq = document.getElementById('approvalSearch')?.value.toLowerCase() || '';
    const tf = document.getElementById('approvalTypeFilter')?.value || '';
    const filtered = this._pendingH.filter(h =>
      `${h.name || ''} ${h.type || ''}`.toLowerCase().includes(sq) && (!tf || h.type === tf)
    );

    if (!filtered.length) {
      if (empty) empty.style.display = 'flex';
      grid.innerHTML = '';
      return;
    }
    if (empty) empty.style.display = 'none';

    const emoji = { 'Combine Harvester': '🌾', 'Rice Harvester': '🌾', 'Corn Harvester': '🌽' };
    grid.innerHTML = filtered.map(h => {
      const img = h.imageUrl
        ? `<img src="${esc(h.imageUrl)}" alt="${esc(h.name)}" loading="lazy">`
        : `<div class="harvester-image-placeholder">${emoji[h.type] || '🚜'}</div>`;
      return `<div class="harvester-card">
        <div class="harvester-image">
          ${img}
          <span class="status-badge pending">Pending Review</span>
        </div>
        <div class="harvester-info">
          <h3>${esc(h.name || 'Unknown')}</h3>
          <p class="harvester-type">${esc(h.type || '-')}</p>
          <div class="specs">
            <div class="spec-item"><span class="spec-label">Owner</span><span class="spec-value">${esc(h.ownerName || '-')}</span></div>
            <div class="spec-item"><span class="spec-label">Rate</span><span class="spec-value">₱${esc(h.rate || 0)}/day</span></div>
          </div>
          <div class="card-actions">
            <button class="btn-approve-card" data-approve-h="${esc(h.id)}">✓ Approve</button>
            <button class="btn-reject-card"  data-reject-h="${esc(h.id)}">✕ Reject</button>
          </div>
        </div>
      </div>`;
    }).join('');

    grid.querySelectorAll('[data-approve-h]').forEach(btn =>
      btn.addEventListener('click', () => this._approveH(btn.dataset.approveH))
    );
    grid.querySelectorAll('[data-reject-h]').forEach(btn =>
      btn.addEventListener('click', () => this._openRejectH(btn.dataset.rejectH))
    );
  }

  async _approveH(id) {
    try {
      // Get the harvester data to check ownerId
      const harvester = this._pendingH.find(h => h.id === id);
      if (!harvester) {
        showToast('Harvester not found', 'error');
        return;
      }

      // Update harvester status
      await updateDoc(doc(db, 'harvesters', id), {
        status: 'available', approvedAt: new Date().toISOString(),
      });

      // Check and update user role to 'owner' if not already
      if (harvester.ownerId) {
        try {
          const userDoc = await getDoc(doc(db, 'users', harvester.ownerId));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            if (userData.role !== 'owner') {
              await updateDoc(doc(db, 'users', harvester.ownerId), {
                role: 'owner',
                updatedAt: new Date().toISOString()
              });
              console.log(`Updated user ${harvester.ownerId} role to 'owner'`);
            }
          }
        } catch (userError) {
          console.warn('[ApprovalsPage] Failed to update user role:', userError);
          // Don't fail the approval if user update fails
        }
      }

      showToast('Harvester approved! ✓');
      this._pendingH = this._pendingH.filter(h => h.id !== id);
      this._updateHStats();
      this._renderHarvesters();
      this._syncBadges();
    } catch (e) {
      console.error('[ApprovalsPage] Approve harvester failed:', e);
      showToast('Approval failed', 'error');
    }
  }

  _openRejectH(id) {
    // FIX: null check before setting value
    const reasonEl = document.getElementById('rejection-reason');
    const hiddenEl = document.getElementById('rejection-harvester-id');
    if (reasonEl) reasonEl.value = '';
    if (hiddenEl) hiddenEl.value = id;
    clearFieldState('rejection-reason', 'err-rejection-reason');
    openModal('rejectionModal');
  }

  async _confirmRejectH() {
    const id     = document.getElementById('rejection-harvester-id')?.value;
    const reason = document.getElementById('rejection-reason')?.value.trim();
    if (!id) return;

    clearFieldState('rejection-reason', 'err-rejection-reason');
    if (!reason) {
      const errEl = document.getElementById('err-rejection-reason');
      if (errEl) errEl.textContent = 'Reason is required';
      setFieldError('rejection-reason', 'err-rejection-reason', true);
      return;
    }
    if (reason.length < 10) {
      const errEl = document.getElementById('err-rejection-reason');
      if (errEl) errEl.textContent = 'Please provide more detail (min 10 characters)';
      setFieldError('rejection-reason', 'err-rejection-reason', true);
      return;
    }
    try {
      await updateDoc(doc(db, 'harvesters', id), {
        status: 'rejected', rejectedAt: new Date().toISOString(), rejectionReason: reason,
      });
      showToast('Listing rejected');
      closeModal('rejectionModal');
      this._pendingH = this._pendingH.filter(h => h.id !== id);
      this._updateHStats();
      this._renderHarvesters();
      this._syncBadges();
    } catch (e) {
      console.error('[ApprovalsPage] Reject harvester failed:', e);
      showToast('Rejection failed', 'error');
    }
  }

  // ── User Verification ──────────────────────────────────────────────────────

  async _loadUsers() {
    showLoading();
    const grid  = document.getElementById('user-approval-grid');
    const empty = document.getElementById('user-approval-empty');
    if (grid)  grid.innerHTML      = '';
    if (empty) empty.style.display = 'none';
    try {
      this._pendingU = [];

      const usersSnap = await getDocs(query(collection(db, 'users'), limit(100)));
      usersSnap.forEach(d => {
        const data = d.data();
        const vs   = data.verificationStatus || data.verification_status || '';
        const st   = data.status || '';

        // FIX: was `(!vs && !st)` which wrongly included ALL users without those fields.
        // Now only include users explicitly pending verification or account approval.
        if (vs === 'pending' || st === 'pending') {
          this._pendingU.push({ id: d.id, ...data, sourceCollection: 'users' });
        }
      });

      // Also check the dedicated verification_requests collection if it exists
      try {
        const vSnap = await getDocs(query(collection(db, 'verification_requests'), limit(100)));
        vSnap.forEach(d => {
          const data = d.data();
          if (!data.status || data.status === 'pending') {
            this._pendingU.push({ id: d.id, ...data, sourceCollection: 'verification_requests' });
          }
        });
      } catch { /* collection may not exist yet */ }

      this._updateUStats();
      this._renderUsers();
      this._syncBadges();
    } catch (e) {
      console.error('[ApprovalsPage] Failed to load user verifications:', e);
      showToast('Failed to load user verifications', 'error');
    }
    hideLoading();
  }

  _updateUStats() {
    const set = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };
    set('user-pending-count',  this._pendingU.length + ' Pending');
    set('user-approved-count', '— Verified Today');
    set('user-rejected-count', '— Rejected Today');
  }

  _renderUsers() {
    const grid  = document.getElementById('user-approval-grid');
    const empty = document.getElementById('user-approval-empty');
    if (!grid) return;

    const sq = document.getElementById('userApprovalSearch')?.value.toLowerCase() || '';
    const tf = document.getElementById('userApprovalTypeFilter')?.value || '';
    const filtered = this._pendingU.filter(u => {
      const name  = getUserName(u)  || 'Unknown';
      const email = getUserEmail(u) || '';
      return `${name} ${email}`.toLowerCase().includes(sq) && (!tf || u.userType === tf);
    });

    if (!filtered.length) {
      if (empty) empty.style.display = 'flex';
      grid.innerHTML = '';
      return;
    }
    if (empty) empty.style.display = 'none';

    grid.innerHTML = filtered.map(u => this._userCardHTML(u)).join('');

    grid.querySelectorAll('[data-approve-u]').forEach(btn =>
      btn.addEventListener('click', () => this._approveU(btn.dataset.approveU))
    );
    grid.querySelectorAll('[data-reject-u]').forEach(btn =>
      btn.addEventListener('click', () => this._openRejectU(btn.dataset.rejectU))
    );
    grid.querySelectorAll('[data-view-u]').forEach(btn =>
      btn.addEventListener('click', () => this._viewUserDetails(btn.dataset.viewU))
    );
    grid.querySelectorAll('[data-lightbox]').forEach(el =>
      el.addEventListener('click', () => this._openLightbox(el.dataset.lightbox, el.dataset.label))
    );
  }

  _userCardHTML(u) {
    const name  = getUserName(u)  || 'Unknown User';
    const email = getUserEmail(u) || '-';
    const color = avatarColor(u.id);
    const ini   = initials(name);

    const slotHTML = (url, label) => url
      ? `<div class="user-id-img-wrap" data-lightbox="${esc(url)}" data-label="${esc(label)}">
           <img src="${esc(url)}" alt="${esc(label)}" loading="lazy">
           <div class="user-id-img-label">${esc(label)}</div>
           <div class="zoom-hint">🔍</div>
         </div>`
      : `<div class="user-id-img-wrap" style="cursor:default;border-style:dashed">
           <div class="user-id-img-placeholder">
             <span style="font-size:22px">${label === 'Selfie' ? '🤳' : '🪪'}</span>
             <span>${esc(label)}</span>
             <span style="font-size:9px;opacity:.55">Not uploaded</span>
           </div>
         </div>`;

    return `<div class="user-approval-card">
      <div class="user-card-header">
        <div class="user-avatar-large" style="background:${color}">${esc(ini)}</div>
        <div class="user-card-info">
          <p class="user-card-name">${esc(name)}</p>
          <p class="user-card-email">${esc(email)}</p>
          <span class="user-card-type ${esc(u.userType || 'Renter')}">${esc(u.userType || 'Renter')}</span>
        </div>
        <span class="status-badge pending" style="position:static;flex-shrink:0;align-self:flex-start">Pending</span>
      </div>
      <div class="user-id-images">
        ${slotHTML(getImageUrl(u, 'idFront'), 'ID Front')}
        ${slotHTML(getImageUrl(u, 'idBack'),  'ID Back')}
        ${slotHTML(getImageUrl(u, 'selfie'),  'Selfie')}
      </div>
      <div class="user-card-meta">
        ${u.phone    ? `<span class="user-meta-item">📞 ${esc(u.phone)}</span>`    : ''}
        ${u.location ? `<span class="user-meta-item">📍 ${esc(u.location)}</span>` : ''}
        ${(u.createdAt || u.submittedAt) ? `<span class="user-meta-item">🗓 ${fmtDate(u.createdAt || u.submittedAt)}</span>` : ''}
      </div>
      <div class="user-card-actions">
        <button class="btn-action"       data-view-u="${esc(u.id)}">View Details</button>
        <button class="btn-approve-card" data-approve-u="${esc(u.id)}">✓ Verify</button>
        <button class="btn-reject-card"  data-reject-u="${esc(u.id)}">✕ Reject</button>
      </div>
    </div>`;
  }

  async _approveU(id) {
    const u = this._pendingU.find(x => x.id === id);
    if (!u) { showToast('User not found', 'error'); return; }
    try {
      const isVerifReq = u.sourceCollection === 'verification_requests';
      const collName   = isVerifReq ? 'verification_requests' : 'users';
      const field      = isVerifReq
        ? { status: 'approved',   approvedAt:  new Date().toISOString() }
        : { verificationStatus: 'verified', verifiedAt: new Date().toISOString() };
      await updateDoc(doc(db, collName, id), field);
      showToast('User verified successfully! ✓');
      this._pendingU = this._pendingU.filter(x => x.id !== id);
      this._updateUStats();
      this._renderUsers();
      this._syncBadges();
    } catch (e) {
      console.error('[ApprovalsPage] Approve user failed:', e);
      showToast('Verification failed', 'error');
    }
  }

  _openRejectU(id) {
    const reasonEl = document.getElementById('user-rejection-reason');
    const hiddenEl = document.getElementById('user-rejection-id');
    if (reasonEl) reasonEl.value = '';
    if (hiddenEl) hiddenEl.value = id;
    clearFieldState('user-rejection-reason', 'err-user-rejection-reason');
    openModal('userRejectionModal');
  }

  async _confirmRejectU() {
    const id     = document.getElementById('user-rejection-id')?.value;
    const reason = document.getElementById('user-rejection-reason')?.value.trim();
    if (!id) return;

    clearFieldState('user-rejection-reason', 'err-user-rejection-reason');
    if (!reason) {
      const errEl = document.getElementById('err-user-rejection-reason');
      if (errEl) errEl.textContent = 'Reason is required';
      setFieldError('user-rejection-reason', 'err-user-rejection-reason', true);
      return;
    }
    if (reason.length < 10) {
      const errEl = document.getElementById('err-user-rejection-reason');
      if (errEl) errEl.textContent = 'Please provide more detail (min 10 characters)';
      setFieldError('user-rejection-reason', 'err-user-rejection-reason', true);
      return;
    }

    const u = this._pendingU.find(x => x.id === id);
    if (!u) { showToast('User not found', 'error'); return; }

    try {
      const isVerifReq = u.sourceCollection === 'verification_requests';
      const collName   = isVerifReq ? 'verification_requests' : 'users';
      const field      = isVerifReq
        ? { status: 'rejected',             rejectedAt: new Date().toISOString(), rejectionReason: reason }
        : { verificationStatus: 'rejected', rejectedAt: new Date().toISOString(), rejectionReason: reason };
      await updateDoc(doc(db, collName, id), field);
      showToast('Verification rejected.');
      closeModal('userRejectionModal');
      this._pendingU = this._pendingU.filter(x => x.id !== id);
      this._updateUStats();
      this._renderUsers();
      this._syncBadges();
    } catch (e) {
      console.error('[ApprovalsPage] Reject user failed:', e);
      showToast('Rejection failed', 'error');
    }
  }

  async _viewUserDetails(id) {
    let u = this._pendingU.find(x => x.id === id);
    if (!u) {
      try {
        const d = await getDoc(doc(db, 'users', id));
        u = d.exists() ? { id: d.id, ...d.data(), sourceCollection: 'users' } : null;
      } catch (e) {
        console.error('[ApprovalsPage] Failed to fetch user details:', e);
      }
    }
    if (!u) { showToast('User not found', 'error'); return; }

    const buildImg = (url, label) => url
      ? `<div style="cursor:pointer" data-lightbox="${esc(url)}" data-label="${esc(label)}">
           <div style="aspect-ratio:4/3;border-radius:8px;overflow:hidden;border:2px solid #e5e7eb;margin-bottom:6px">
             <img src="${esc(url)}" alt="${esc(label)}" style="width:100%;height:100%;object-fit:cover">
           </div>
           <div style="font-size:11px;font-weight:700;text-align:center;color:#374151">${esc(label)}</div>
         </div>`
      : `<div style="aspect-ratio:4/3;border-radius:8px;border:2px dashed #e5e7eb;display:flex;align-items:center;justify-content:center;background:#f9fafb">
           <div style="font-size:11px;color:#9ca3af;text-align:center">${esc(label)}<br><span style="font-size:9px">Not uploaded</span></div>
         </div>`;

    const body = document.getElementById('user-view-details-body');
    if (!body) return;

    body.innerHTML = `
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">
        <div class="modal-field"><label>Full Legal Name</label>
          <div class="modal-val">${esc(u.fullLegalName || u.fullName || u.name || 'Not provided')}</div></div>
        <div class="modal-field"><label>Date of Birth</label>
          <div class="modal-val">${formatDob(u.dateOfBirth || u.dob)}</div></div>
        <div class="modal-field" style="grid-column:span 2"><label>Address</label>
          <div class="modal-val">${esc(u.permanentAddress || u.address || u.location || 'Not provided')}</div></div>
        <div class="modal-field"><label>ID Type</label>
          <div class="modal-val">${esc(u.idType || u.id_type || 'Not provided')}</div></div>
        <div class="modal-field"><label>ID Number</label>
          <div class="modal-val mono">${esc(u.idDocumentNumber || u.idNumber || u.id_number || 'Not provided')}</div></div>
        <div class="modal-field"><label>Email</label>
          <div class="modal-val">${esc(getUserEmail(u) || 'Not provided')}</div></div>
        <div class="modal-field"><label>Phone</label>
          <div class="modal-val">${esc(getUserPhone(u) || 'Not provided')}</div></div>
      </div>
      <h4 style="font-size:13px;font-weight:700;color:var(--text-dark);margin:16px 0 12px;padding-top:16px;border-top:1px solid #e5e7eb">
        📋 Verification Documents
      </h4>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
        ${buildImg(getImageUrl(u, 'idFront'), 'ID Front')}
        ${buildImg(getImageUrl(u, 'idBack'),  'ID Back')}
        ${buildImg(getImageUrl(u, 'selfie'),  'Selfie')}
      </div>`;

    body.querySelectorAll('[data-lightbox]').forEach(el =>
      el.addEventListener('click', () => this._openLightbox(el.dataset.lightbox, el.dataset.label))
    );
    openModal('userViewDetailsModal');
  }

  _openLightbox(url, label) {
    const img = document.getElementById('lightbox-img');
    const lbl = document.getElementById('lightbox-label');
    if (img) img.src          = url;
    if (lbl) lbl.textContent  = label;
    openModal('imageLightboxModal');
  }

  _syncBadges() {
    this._onBadgeUpdate(this._pendingH, this._pendingU);
  }

  /** Switch between harvester and user verification sub-tabs */
  switchTab(tab) {
    this._currentTab = tab;
    this._uiBound    = false; // reset so re-binding works if HTML was re-injected
    this._bindTabUI();

    ['harvesters', 'users'].forEach(t => {
      document.getElementById(`nav-approvals-${t}`)?.classList.toggle('active', t === tab);
      const tabEl = document.getElementById(`tab-${t}-approvals`);
      if (tabEl) tabEl.style.display = t === tab ? '' : 'none';
    });

    const titles = {
      harvesters: ['Harvester Approvals',   'Review and approve harvester listings from the mobile app'],
      users:      ['Identity Verification', 'Review ID and selfie submissions for account verification'],
    };
    // FIX: null-safe — elements may not exist if navigating before page load completes
    const titleEl    = document.getElementById('approvals-page-title');
    const subtitleEl = document.getElementById('approvals-page-subtitle');
    if (titleEl)    titleEl.textContent    = titles[tab][0];
    if (subtitleEl) subtitleEl.textContent = titles[tab][1];

    if (tab === 'users') this._loadUsers();
    else                 this._loadHarvesters();
  }
}
