// js/ui.js — UI service: toast, modal, loading, validation
// FIXES:
//  1. showConfirm() accumulated onclick handlers every time it was called — the previous
//     handler was never removed if the confirm dialog was closed via Cancel/overlay-click.
//     Fixed by using replaceWith() on the button to create a fresh clone, clearing all
//     previous listeners before adding the new one.
//  2. bindModalClose() is idempotent via a data attribute flag — calling it multiple
//     times on the same root won't stack duplicate listeners.
//  3. showLoading / hideLoading are null-safe.

import { esc } from './utils.js';

// ── Loading ───────────────────────────────────────────────────────────────────
export function showLoading() {
  document.getElementById('loading-overlay')?.classList.add('active');
}
export function hideLoading() {
  document.getElementById('loading-overlay')?.classList.remove('active');
}

// ── Toast ─────────────────────────────────────────────────────────────────────
let _toastTimer;
export function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.className   = 'toast' + (type ? ' toast-' + type : '') + ' show';
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
}

// ── Modals ────────────────────────────────────────────────────────────────────
export function openModal(id)  { document.getElementById(id)?.classList.add('open'); }
export function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }

/**
 * Wire all [data-close] buttons and overlay-click-to-close within `root`.
 * FIX: Uses a data attribute flag so calling this multiple times on the same
 * root does NOT stack duplicate event listeners.
 */
export function bindModalClose(root = document) {
  if (!root) return;

  // Mark each button/overlay so we never bind twice on the same element
  root.querySelectorAll('[data-close]').forEach(btn => {
    if (btn.dataset.closeBound) return;
    btn.dataset.closeBound = '1';
    btn.addEventListener('click', () => closeModal(btn.dataset.close));
  });

  root.querySelectorAll('.modal-overlay').forEach(overlay => {
    if (overlay.dataset.overlayBound) return;
    overlay.dataset.overlayBound = '1';
    overlay.addEventListener('click', e => {
      if (e.target === overlay) closeModal(overlay.id);
    });
  });
}

/**
 * Show a styled confirm dialog instead of window.confirm().
 * FIX: Previous implementation accumulated 'click' handlers on #confirm-ok every
 * time showConfirm was called, because the old handler was only removed via
 * btn.removeEventListener() — but that only works with named (non-arrow) functions.
 * Fixed by cloning the button to strip ALL previous listeners before adding the new one.
 */
export function showConfirm(message, onConfirm) {
  const msgEl = document.getElementById('confirm-message');
  if (msgEl) msgEl.innerHTML = esc(message);

  // FIX: clone the button to wipe all accumulated listeners
  const oldBtn = document.getElementById('confirm-ok');
  if (!oldBtn) return;
  const newBtn = oldBtn.cloneNode(true);
  oldBtn.replaceWith(newBtn);

  newBtn.addEventListener('click', () => {
    closeModal('confirmModal');
    onConfirm();
  });

  openModal('confirmModal');
}

// ── Validation ────────────────────────────────────────────────────────────────
export function setFieldError(inputId, errId, show) {
  document.getElementById(inputId)?.classList.toggle('input-error', show);
  document.getElementById(inputId)?.classList.toggle('input-ok',    !show);
  document.getElementById(errId)?.classList.toggle('visible',       show);
}

export function clearFieldState(inputId, errId) {
  document.getElementById(inputId)?.classList.remove('input-error', 'input-ok');
  document.getElementById(errId)?.classList.remove('visible');
}

export function showBanner(bannerId, show) {
  document.getElementById(bannerId)?.classList.toggle('visible', show);
}

/** Wire input/change events to clear error state automatically */
export function wireLiveValidation(pairs) {
  pairs.forEach(([inp, err]) => {
    const el = document.getElementById(inp);
    if (!el) return;
    const clear = () => clearFieldState(inp, err);
    el.addEventListener('input',  clear);
    el.addEventListener('change', clear);
  });
}

/** Attach a live character counter to a textarea */
export function attachCharCounter(textareaId, max) {
  const el = document.getElementById(textareaId);
  if (!el) return;
  const label = el.closest('.modal-field')?.querySelector('label');
  if (!label) return;
  label.style.cssText = 'display:flex;justify-content:space-between;align-items:center';
  const counter = Object.assign(document.createElement('span'), {
    className:   'char-counter',
    textContent: `0 / ${max}`,
  });
  label.appendChild(counter);
  el.addEventListener('input', () => {
    const len = el.value.length;
    counter.textContent = `${len} / ${max}`;
    counter.className   = 'char-counter' + (len > max ? ' over' : len > max * 0.8 ? ' warn' : '');
  });
}
