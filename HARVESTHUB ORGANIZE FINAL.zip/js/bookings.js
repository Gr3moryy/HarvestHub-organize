// js/pages/bookings.js
// FIXES:
//  1. File was missing entirely — recreated.
//  2. fmtDate() now uses the toDate() helper to handle Firestore Timestamp objects
//     in addition to string date values.
//  3. _view() reads all fields with null safety (?.textContent pattern).
//  4. Status badge class is sanitised with esc() to prevent XSS from Firestore data.
//  5. catch block in load() logs the actual error for debugging.

import { db } from '../firebase.js';
import {
  showToast, showLoading, hideLoading,
  openModal, bindModalClose, showConfirm,
} from '../ui.js';
import { fmtDate, esc, cap, debounce } from '../utils.js';
import {
  collection, query, orderBy, limit, getDocs, doc, deleteDoc,
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js';

/** Convert a Firestore Timestamp or string to a JS Date safely */
function toDate(val) {
  if (!val) return new Date(NaN);
  if (typeof val.toDate === 'function') return val.toDate(); // Firestore Timestamp
  return new Date(val);
}

export class BookingsPage {
  constructor() {
    this._data   = [];
    this._render = debounce(() => this._renderTable());
  }

  async load() {
    showLoading();
    try {
      this._data = [];
      let snap;
      try {
        // Preferred: ordered by creation date descending
        snap = await getDocs(query(collection(db, 'bookings'), orderBy('createdAt', 'desc'), limit(25)));
      } catch {
        // Fallback if the index doesn't exist yet
        snap = await getDocs(query(collection(db, 'bookings'), limit(25)));
      }
      snap.forEach(d => this._data.push({ id: d.id, ...d.data() }));
      // Client-side sort as safety net in case orderBy fallback was used
      this._data.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      this._bindUI();
      this._renderTable();
    } catch (e) {
      console.error('[BookingsPage] Failed to load bookings:', e);
      showToast('Failed to load bookings', 'error');
    }
    hideLoading();
  }

  _bindUI() {
    document.getElementById('bookingSearch')?.addEventListener('input', this._render);
    document.getElementById('bookingStatusFilter')?.addEventListener('change', this._render);
    bindModalClose(document.getElementById('main-content'));
  }

  _renderTable() {
    const tb = document.getElementById('booking-tbody');
    if (!tb) return;

    const sq = document.getElementById('bookingSearch')?.value.toLowerCase() || '';
    const sf = document.getElementById('bookingStatusFilter')?.value || '';

    const filtered = this._data.filter(b =>
      `${b.id} ${b.renterName || ''} ${b.harvesterName || ''}`.toLowerCase().includes(sq) &&
      (!sf || b.status === sf)
    );

    if (!filtered.length) {
      tb.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:30px;color:#9aaa9a">No bookings found</td></tr>';
      return;
    }

    tb.innerHTML = filtered.map(b => {
      // FIX: use toDate() to handle Firestore Timestamp objects
      const startDate = toDate(b.startDate);
      const endDate   = toDate(b.endDate);
      return `<tr>
        <td style="font-family:monospace;font-size:12px;color:#7a907a">${esc(b.id.substring(0, 8))}</td>
        <td>${esc(b.renterName    || '-')}</td>
        <td>${esc(b.harvesterName || '-')}</td>
        <td>${esc(b.location      || '-')}</td>
        <td>${fmtDate(startDate)}</td>
        <td>${fmtDate(endDate)}</td>
        <td style="font-weight:700;color:#2d7a2d">₱${esc(b.totalCost || 0)}</td>
        <td><span class="badge ${esc(b.status || '')}">${cap(b.status)}</span></td>
        <td>
          <button class="btn-action" data-action="view" data-id="${esc(b.id)}">View</button>
          <button class="btn-delete" data-action="delete" data-id="${esc(b.id)}">Delete</button>
        </td>
      </tr>`;
    }).join('');

    tb.querySelectorAll('button[data-action]').forEach(btn => {
      const id = btn.dataset.id;
      const action = btn.dataset.action;
      if (action === 'view') {
        btn.addEventListener('click', () => this._view(id));
      } else if (action === 'delete') {
        btn.addEventListener('click', () => this._confirmDelete(id));
      }
    });
  }

  _view(id) {
    const b = this._data.find(x => x.id === id);
    if (!b) return;

    // FIX: null-safe element updates using optional chaining
    const set = (elId, val) => {
      const el = document.getElementById(elId);
      if (el) el.textContent = val;
    };

    set('bmv-id',        'Booking #' + id.substring(0, 8).toUpperCase());
    set('bmv-renter',    b.renterName    || '-');
    set('bmv-harvester', b.harvesterName || '-');
    set('bmv-location',  b.location      || '-');
    set('bmv-cost',      '₱' + (b.totalCost || 0));
    set('bmv-start',     fmtDate(toDate(b.startDate)));
    set('bmv-end',       fmtDate(toDate(b.endDate)));
    set('bmv-full-id',   id);

    const lbl = document.getElementById('bmv-status-label');
    if (lbl) {
      lbl.textContent = cap(b.status);
      lbl.className   = 'modal-status-label ' + esc(b.status || '');
    }

    const deleteBtn = document.getElementById('bmv-delete-btn');
    if (deleteBtn) {
      deleteBtn.onclick = () => this._confirmDelete(id);
    }

    openModal('bookingViewModal');
  }

  _confirmDelete(id) {
    const booking = this._data.find(x => x.id === id);
    if (!booking) return;

    showConfirm(
      `Delete booking <strong>${esc(id.substring(0, 8))}</strong> for <strong>${esc(booking.renterName || 'customer')}</strong>? This cannot be undone.`,
      async () => {
        await this._delete(id);
      }
    );
  }

  async _delete(id) {
    showLoading();
    try {
      await deleteDoc(doc(db, 'bookings', id));
      showToast('Booking deleted');
      await this.load();
    } catch (e) {
      console.error('[BookingsPage] Failed to delete booking:', e);
      showToast('Delete failed', 'error');
    } finally {
      hideLoading();
    }
  }
}
