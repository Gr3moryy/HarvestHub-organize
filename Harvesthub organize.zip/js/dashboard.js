// js/pages/dashboard.js
// FIXES:
//  1. new Date(b.startDate) / new Date(b.endDate) could produce Invalid Date if the
//     Firestore field is a Timestamp object (not a string). Added .toDate() handling.
//  2. Math.ceil((e - s) / 86400000) in upcoming table could produce NaN if either date
//     is invalid — added isNaN guard.
//  3. Errors in _loadCurrentRentals and _loadUpcoming are now logged properly.

import { db } from '../firebase.js';
import { showToast, showLoading, hideLoading } from '../ui.js';
import { fmtDate, esc, animateCount } from '../utils.js';
import {
  collection, query, where, getDocs, orderBy, limit, getCountFromServer,
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js';

/** Convert a Firestore field value (Timestamp or string) to a JS Date */
function toDate(val) {
  if (!val) return new Date(NaN);
  // Firestore Timestamp objects have a .toDate() method
  if (typeof val.toDate === 'function') return val.toDate();
  return new Date(val);
}

export class DashboardPage {
  async load() {
    showLoading();
    try {
      const [totalSnap, availSnap, bSnap] = await Promise.all([
        getCountFromServer(collection(db, 'bookings')),
        getCountFromServer(query(collection(db, 'harvesters'), where('status', '==', 'available'))),
        getDocs(query(collection(db, 'bookings'), where('status', 'in', ['confirmed', 'pending']), limit(200))),
      ]);

      this._setStat('stat-total-bookings',       totalSnap.data().count);
      this._setStat('stat-available-harvesters', availSnap.data().count);

      const today = new Date();
      let active = 0, upcoming = 0;
      bSnap.forEach(d => {
        const b = d.data();
        // FIX: use toDate() helper to handle both Timestamp and string fields
        const s = toDate(b.startDate);
        const e = toDate(b.endDate);
        if (isNaN(s) || isNaN(e)) return; // skip malformed records
        if (b.status === 'confirmed' && today >= s && today <= e) active++;
        if ((b.status === 'confirmed' || b.status === 'pending') && s > today) upcoming++;
      });

      this._setStat('stat-active-rentals',    active);
      this._setStat('stat-upcoming-services', upcoming);

      await Promise.all([this._loadCurrentRentals(), this._loadUpcoming()]);
    } catch (e) {
      console.error('[DashboardPage] Failed to load stats:', e);
      showToast('Failed to load dashboard', 'error');
    }
    hideLoading();
  }

  _setStat(id, val) {
    const el = document.getElementById(id);
    if (!el) return;
    if (el.hasAttribute('data-count') && typeof val === 'number') animateCount(el, val);
    else el.textContent = val;
  }

  async _loadCurrentRentals() {
    const tb = document.getElementById('current-rentals-tbody');
    if (!tb) return;
    try {
      const snap  = await getDocs(query(collection(db, 'bookings'), where('status', '==', 'confirmed'), limit(10)));
      const today = new Date();
      const rows  = [];
      snap.forEach(d => {
        const b = d.data();
        const s = toDate(b.startDate);
        const e = toDate(b.endDate);
        if (isNaN(s) || isNaN(e)) return;
        if (today >= s && today <= e && rows.length < 5) {
          rows.push(`<tr>
            <td>${esc(b.renterName    || '-')}</td>
            <td>${esc(b.harvesterName || '-')}</td>
            <td>${esc(b.location      || '-')}</td>
            <td>${fmtDate(s)} – ${fmtDate(e)}</td>
          </tr>`);
        }
      });
      tb.innerHTML = rows.length
        ? rows.join('')
        : '<tr><td colspan="4" style="text-align:center;color:#9aaa9a;padding:20px">No active rentals</td></tr>';
    } catch (e) {
      console.error('[DashboardPage] Failed to load current rentals:', e);
      tb.innerHTML = '<tr><td colspan="4">Error loading rentals</td></tr>';
    }
  }

  async _loadUpcoming() {
    const tb = document.getElementById('upcoming-bookings-tbody');
    if (!tb) return;
    try {
      const snap  = await getDocs(query(collection(db, 'bookings'), orderBy('startDate', 'asc'), limit(20)));
      const today = new Date();
      const rows  = [];
      snap.forEach(d => {
        const b = d.data();
        const s = toDate(b.startDate);
        const e = toDate(b.endDate);
        if (isNaN(s) || isNaN(e)) return;
        if (s > today && (b.status === 'confirmed' || b.status === 'pending') && rows.length < 5) {
          // FIX: guard against NaN duration before rendering
          const days = Math.ceil((e - s) / 86400000);
          const daysStr = isNaN(days) ? '?' : days + 'd';
          rows.push(`<tr>
            <td>${esc(b.renterName    || '-')}</td>
            <td>${esc(b.harvesterName || '-')}</td>
            <td>${fmtDate(s)}</td>
            <td>${daysStr}</td>
          </tr>`);
        }
      });
      tb.innerHTML = rows.length
        ? rows.join('')
        : '<tr><td colspan="4" style="text-align:center;color:#9aaa9a;padding:20px">No upcoming bookings</td></tr>';
    } catch (e) {
      console.error('[DashboardPage] Failed to load upcoming bookings:', e);
      tb.innerHTML = '<tr><td colspan="4">Error loading bookings</td></tr>';
    }
  }
}
