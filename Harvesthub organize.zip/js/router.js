// js/router.js — Loads HTML page fragments into #main-content
// FIXES:
//  1. _current was set BEFORE the fetch completed. If fetch failed, the page was
//     permanently "locked" — navigating to it again would silently skip it because
//     this._current === page. Fixed: only commit _current after a successful fetch.
//  2. Added _navigating flag to prevent overlapping concurrent navigate() calls.
//  3. navigate() now correctly returns a resolved Promise even when skipping (same page).
//  4. _fetchPage no longer caches failed responses — a failed load can be retried.

import { bindModalClose } from './ui.js';

export class Router {
  /**
   * @param {string} contentSelector — CSS selector for the content container
   * @param {Object} pageLoaders     — { pageName: asyncFunction } called after HTML is injected
   */
  constructor(contentSelector, pageLoaders = {}) {
    this._container  = document.querySelector(contentSelector);
    this._loaders    = pageLoaders;
    this._current    = null;
    this._cache      = {};   // only caches successful fetches
    this._navigating = false; // FIX: guard against overlapping navigations
  }

  /** Register additional page loaders after construction */
  register(pageLoaders) {
    Object.assign(this._loaders, pageLoaders);
  }

  /** Navigate to a page by name. Returns a Promise that resolves when fully loaded. */
  async navigate(page) {
    // Same page — skip, but still return a resolved promise
    if (this._current === page) return;

    // FIX: prevent overlapping concurrent navigate calls
    if (this._navigating) return;
    this._navigating = true;

    try {
      this._updateSidebar(page);

      const html = await this._fetchPage(page);

      // FIX: only commit _current AFTER successful fetch.
      // Previously _current was set at the top, so a failed fetch would permanently
      // lock the page and block any future retry attempt.
      this._current = page;

      this._container.innerHTML = html;

      // Re-bind modal close buttons injected with the page HTML
      bindModalClose(this._container);

      // Call the page's JS loader
      await this._loaders[page]?.();
    } catch (e) {
      console.error(`[Router] Navigation to "${page}" failed:`, e);
      this._container.innerHTML = `
        <div class="empty-state">
          <h3>Page Load Error</h3>
          <p>Could not load "${page}". Please try again.</p>
        </div>`;
    } finally {
      // FIX: always release the navigation lock
      this._navigating = false;
    }
  }

  /** Force-reload the current page (clears cache for that page) */
  async reload() {
    if (!this._current) return;
    const page = this._current;
    delete this._cache[page];  // bust cache so it re-fetches
    this._current = null;       // clear so navigate() doesn't skip
    await this.navigate(page);
  }

  async _fetchPage(page) {
    if (this._cache[page]) return this._cache[page];
    const res = await fetch(`./${page}.html`);
    if (!res.ok) throw new Error(`HTTP ${res.status} loading "${page}.html"`);
    const html = await res.text();
    // FIX: only cache on success — failed fetches are not stored so they can be retried
    this._cache[page] = html;
    return html;
  }

  _updateSidebar(page) {
    document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
    document.getElementById('nav-' + page)?.classList.add('active');
  }

  get current() { return this._current; }
}
