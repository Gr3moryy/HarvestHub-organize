// js/pages/harvesters.js
// FIXES:
//  1. _save() called load() even on add-new path (which isn't needed since new harvesters
//     go to pending and don't appear in the fleet list). Removed unnecessary reload.
//  2. catch blocks now log the actual error object for better debugging.
//  3. _validate() now reads element values with null safety.
//  4. openEdit() null-checks every getElementById call before accessing properties.

import { db } from '../firebase.js';
import {
  showToast, showLoading, hideLoading,
  openModal, closeModal, showConfirm,
  setFieldError, clearFieldState, showBanner,
  wireLiveValidation, bindModalClose,
} from '../ui.js';
import { esc, cap, debounce, setSelect } from '../utils.js';
import {
  collection, query, where, limit, getDocs,
  updateDoc, deleteDoc, addDoc, doc,
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js';

export class HarvestersPage {
  constructor() {
    this._data   = [];
    this._render = debounce(() => this._renderGrid());
  }

  async load() {
    showLoading();
    try {
      this._data = [];
      const snap = await getDocs(query(
        collection(db, 'harvesters'),
        where('status', 'in', ['available', 'rented', 'maintenance']),
        limit(25),
      ));
      snap.forEach(d => this._data.push({ id: d.id, ...d.data() }));
      this._bindUI();
      this._updateStats();
      this._renderGrid();
    } catch (e) {
      console.error('[HarvestersPage] Failed to load harvesters:', e);
      showToast('Failed to load harvesters', 'error');
    }
    hideLoading();
  }

  _bindUI() {
    document.getElementById('harvesterSearch')?.addEventListener('input', this._render);
    document.getElementById('harvesterTypeFilter')?.addEventListener('change', this._render);
    document.getElementById('harvesterStatusFilter')?.addEventListener('change', this._render);
    document.getElementById('hem-save-btn')?.addEventListener('click', () => this._save());
    document.getElementById('hem-delete-btn')?.addEventListener('click', () => this._delete());
    wireLiveValidation([
      ['hem-name',     'err-hem-name'],
      ['hem-year',     'err-hem-year'],
      ['hem-rate',     'err-hem-rate'],
      ['hem-location', 'err-hem-location'],
      ['hem-owner',    'err-hem-owner'],
    ]);
    bindModalClose(document.getElementById('main-content'));
  }

  _updateStats() {
    const count = s => this._data.filter(h => h.status === s).length;
    const set   = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };
    set('harvester-available',   count('available')   + ' Available');
    set('harvester-rented',      count('rented')      + ' In Use');
    set('harvester-maintenance', count('maintenance') + ' Maintenance');
  }

  _renderGrid() {
    const grid = document.getElementById('harvester-grid');
    if (!grid) return;

    const sq = document.getElementById('harvesterSearch')?.value.toLowerCase()   || '';
    const tf = document.getElementById('harvesterTypeFilter')?.value              || '';
    const sf = document.getElementById('harvesterStatusFilter')?.value            || '';

    const filtered = this._data.filter(h =>
      `${h.name || ''} ${h.type || ''}`.toLowerCase().includes(sq) &&
      (!tf || h.type   === tf) &&
      (!sf || h.status === sf)
    );

    if (!filtered.length) {
      grid.innerHTML = '<div class="empty-state"><h3>No Harvesters Found</h3><p>Try adjusting your filters.</p></div>';
      return;
    }

    grid.innerHTML = filtered.map(h => this._cardHTML(h)).join('');
    grid.querySelectorAll('[data-edit]').forEach(btn =>
      btn.addEventListener('click', () => this.openEdit(btn.dataset.edit))
    );
  }

  _cardHTML(h) {
    const emoji = { 'Combine Harvester': '🌾', 'Rice Harvester': '🌾', 'Corn Harvester': '🌽' };
    const img = h.imageUrl
      ? `<img src="${esc(h.imageUrl)}" alt="${esc(h.name)}" loading="lazy">`
      : `<div class="harvester-image-placeholder">${emoji[h.type] || '🚜'}</div>`;
    return `<div class="harvester-card">
      <div class="harvester-image">
        ${img}
        <span class="status-badge ${esc(h.status || 'available')}">${cap(h.status)}</span>
      </div>
      <div class="harvester-info">
        <h3>${esc(h.name || 'Unknown')}</h3>
        <p class="harvester-type">${esc(h.type || '-')}</p>
        <div class="specs">
          <div class="spec-item"><span class="spec-label">ID</span><span class="spec-value">${esc(h.id.substring(0, 8))}</span></div>
          <div class="spec-item"><span class="spec-label">Rate</span><span class="spec-value">₱${esc(h.rate || 0)}/day</span></div>
          <div class="spec-item"><span class="spec-label">Year</span><span class="spec-value">${esc(h.year || '-')}</span></div>
          <div class="spec-item"><span class="spec-label">Location</span><span class="spec-value">${esc(h.location || '-')}</span></div>
        </div>
        <div class="card-actions">
          <button class="btn-action" data-edit="${esc(h.id)}">Edit</button>
        </div>
      </div>
    </div>`;
  }

  openEdit(id) {
    const h = this._data.find(x => x.id === id);
    if (!h) return;

    // FIX: null-safe reads on every getElementById
    const setVal = (elId, val) => { const el = document.getElementById(elId); if (el) el.value = val ?? ''; };
    const titleEl = document.getElementById('hem-title');
    if (titleEl) titleEl.textContent = 'Edit Harvester';

    document.getElementById('hem-doc-id').value = id;
    setVal('hem-name',     h.name);
    setVal('hem-year',     h.year);
    setVal('hem-capacity', h.capacity);
    setVal('hem-rate',     h.rate);
    setVal('hem-location', h.location);
    setVal('hem-owner',    h.ownerName);

    setSelect('hem-type',   h.type   || 'Combine Harvester');
    setSelect('hem-status', h.status || 'available');

    document.getElementById('hem-status')?.closest('.modal-field')?.style.removeProperty('display');
    const noteEl   = document.getElementById('hem-approval-note');
    const saveBtnEl = document.getElementById('hem-save-btn');
    const delBtnEl  = document.getElementById('hem-delete-btn');
    if (noteEl)    noteEl.style.display    = 'none';
    if (saveBtnEl) saveBtnEl.textContent   = 'Save';
    if (delBtnEl)  delBtnEl.style.display  = 'inline-flex';

    openModal('harvesterEditModal');
  }

  _validate() {
    [
      ['hem-name', 'err-hem-name'], ['hem-year', 'err-hem-year'],
      ['hem-rate', 'err-hem-rate'], ['hem-location', 'err-hem-location'],
      ['hem-owner', 'err-hem-owner'],
    ].forEach(([i, e]) => clearFieldState(i, e));
    showBanner('hem-banner', false);

    let errors = 0;

    const name = document.getElementById('hem-name')?.value.trim() || '';
    if (!name || name.length < 2) {
      const errEl = document.getElementById('err-hem-name');
      if (errEl) errEl.textContent = !name ? 'Name is required' : 'Min 2 characters';
      setFieldError('hem-name', 'err-hem-name', true);
      errors++;
    }

    const yearVal = document.getElementById('hem-year')?.value || '';
    const year    = parseInt(yearVal);
    if (yearVal && (isNaN(year) || year < 1900 || year > new Date().getFullYear() + 1)) {
      const errEl = document.getElementById('err-hem-year');
      if (errEl) errEl.textContent = 'Enter a valid year (1900–present)';
      setFieldError('hem-year', 'err-hem-year', true);
      errors++;
    }

    const rateVal = document.getElementById('hem-rate')?.value.trim() || '';
    const rate    = parseFloat(rateVal);
    if (!rateVal) {
      const errEl = document.getElementById('err-hem-rate');
      if (errEl) errEl.textContent = 'Daily rate is required';
      setFieldError('hem-rate', 'err-hem-rate', true);
      errors++;
    } else if (isNaN(rate) || rate < 0) {
      const errEl = document.getElementById('err-hem-rate');
      if (errEl) errEl.textContent = 'Rate must be a positive number';
      setFieldError('hem-rate', 'err-hem-rate', true);
      errors++;
    }

    const location = document.getElementById('hem-location')?.value.trim() || '';
    if (!location) {
      setFieldError('hem-location', 'err-hem-location', true);
      errors++;
    }

    const owner = document.getElementById('hem-owner')?.value.trim() || '';
    if (!owner || owner.length < 2) {
      const errEl = document.getElementById('err-hem-owner');
      if (errEl) errEl.textContent = !owner ? 'Owner name is required' : 'Min 2 characters';
      setFieldError('hem-owner', 'err-hem-owner', true);
      errors++;
    }

    if (errors) showBanner('hem-banner', true);
    return errors === 0;
  }

  async _save() {
    if (!this._validate()) return;

    const id = document.getElementById('hem-doc-id')?.value || '';
    const data = {
      name:      document.getElementById('hem-name').value.trim(),
      type:      document.getElementById('hem-type').value,
      year:      document.getElementById('hem-year').value || null,
      capacity:  document.getElementById('hem-capacity').value.trim(),
      rate:      document.getElementById('hem-rate').value.trim(),
      location:  document.getElementById('hem-location').value.trim(),
      ownerName: document.getElementById('hem-owner').value.trim(),
      updatedAt: new Date().toISOString(),
    };

    try {
      if (id) {
        data.status = document.getElementById('hem-status').value;
        await updateDoc(doc(db, 'harvesters', id), data);
        showToast('Harvester updated ✓', 'success');
        closeModal('harvesterEditModal');
        await this.load();  // refresh fleet list
      } else {
        // FIX: New harvesters go to 'pending' — they won't appear in the fleet list.
        // No need to call load() which would show no change and confuse the user.
        data.status    = 'pending';
        data.createdAt = new Date().toISOString();
        await addDoc(collection(db, 'harvesters'), data);
        showToast('Submitted for approval ✓', 'success');
        closeModal('harvesterEditModal');
        // Don't reload — new item won't appear here; it shows in the Approvals page.
      }
    } catch (e) {
      console.error('[HarvestersPage] Failed to save harvester:', e);
      showToast('Failed to save harvester', 'error');
    }
  }

  async _delete() {
    const id = document.getElementById('hem-doc-id')?.value || '';
    if (!id) return;
    showConfirm('Delete this harvester permanently? This cannot be undone.', async () => {
      try {
        await deleteDoc(doc(db, 'harvesters', id));
        showToast('Harvester deleted');
        closeModal('harvesterEditModal');
        await this.load();
      } catch (e) {
        console.error('[HarvestersPage] Failed to delete harvester:', e);
        showToast('Delete failed', 'error');
      }
    });
  }

  /** Called externally after an approval to silently refresh the cache */
  async refreshCache() {
    try {
      const snap = await getDocs(query(
        collection(db, 'harvesters'),
        where('status', 'in', ['available', 'rented', 'maintenance']),
        limit(25),
      ));
      this._data = [];
      snap.forEach(d => this._data.push({ id: d.id, ...d.data() }));
    } catch (e) {
      console.warn('[HarvestersPage] Cache refresh failed:', e);
    }
  }
}
