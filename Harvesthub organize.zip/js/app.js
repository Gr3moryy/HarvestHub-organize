// js/app.js — Loaded by pages/shell.html
// FIXES:
//  1. `notif` declared BEFORE `approvals` so the badge-update callback closure is safe
//  2. openApprovalsMenu() is now async and awaits router.navigate() before switchTab()
//  3. goApprovals() is now async and properly awaits the page load
//  4. Approvals sidebar toggle won't re-navigate if page is already loaded (avoids flicker)
//  5. showToast removed from import — it was imported but never called in this file
//  6. Auth guard only redirects when auth state is definitively resolved (avoids flash)

import { auth, isAdmin }               from './firebase.js';
import { showConfirm, bindModalClose }  from './ui.js';
import { Router }                       from './router.js';
import { NotifManager }                 from './notif.js';
import { DashboardPage }                from './dashboard.js';
import { BookingsPage }                 from './bookings.js';
import { HarvestersPage }               from './harvesters.js';
import { ApprovalsPage }                from './approvals.js';
import { CustomersPage }                from './customers.js';
import { SettingsPage }                 from './settings.js';
import {
  onAuthStateChanged, signOut,
} from 'https://www.gstatic.com/firebasejs/11.0.0/firebase-auth.js';

// ── Auth Guard ────────────────────────────────────────────────────────────────
// Redirect unauthenticated visitors back to the login page.
// onAuthStateChanged fires once on load with the persisted session (or null).
onAuthStateChanged(auth, user => {
  if (!user || !isAdmin(user)) {
    if (user) signOut(auth);             // signed-in but not admin → sign out
    window.location.replace('index.html');
  }
});

// ── Page controllers ──────────────────────────────────────────────────────────
const dashboard  = new DashboardPage();
const bookings   = new BookingsPage();
const harvesters = new HarvestersPage();
const customers  = new CustomersPage();
const settings   = new SettingsPage();

// FIX: Declare `notif` BEFORE `approvals` so the badge-update closure can safely reference it.
// (Even though closures capture by reference and the callback fires async, declaring notif
//  first makes the dependency order explicit and avoids any risk of TDZ issues.)
const notif = new NotifManager((tab) => goApprovals(tab));

// ApprovalsPage receives a callback to push badge counts up to NotifManager.
const approvals = new ApprovalsPage((pendingH, pendingU) => {
  notif.updateBadges(pendingH, pendingU);
});

// ── Router ────────────────────────────────────────────────────────────────────
const router = new Router('#main-content', {
  dashboard:  () => dashboard.load(),
  bookings:   () => bookings.load(),
  harvesters: () => harvesters.load(),
  approvals:  () => approvals.load(),
  customers:  () => customers.load(),
  settings:   () => settings.load(),
});

// ── Navigation helpers ────────────────────────────────────────────────────────

// FIX: async so we can await the page load before calling switchTab.
// Previously router.navigate() was called without await, causing switchTab()
// to run before HTML was injected — all getElementById() calls returned null.
async function goApprovals(tab = 'harvesters') {
  await openApprovalsMenu();
  approvals.switchTab(tab);
}

// FIX: made async + awaits router.navigate() so HTML is in the DOM before any
// downstream code tries to query elements inside the approvals page.
async function openApprovalsMenu() {
  document.getElementById('nav-approvals-group')?.classList.add('open');
  document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
  document.getElementById('nav-approvals')?.classList.add('active');
  // FIX: await the navigation so the fragment is rendered before callers proceed
  await router.navigate('approvals');
}

// ── Sidebar wiring ────────────────────────────────────────────────────────────
function initSidebar() {
  // Regular page links
  document.querySelectorAll('.sidebar-link[data-page]').forEach(btn => {
    btn.addEventListener('click', () => router.navigate(btn.dataset.page));
  });

  // Approvals group toggle
  document.getElementById('nav-approvals')?.addEventListener('click', async () => {
    const group  = document.getElementById('nav-approvals-group');
    const isOpen = group.classList.toggle('open');
    // FIX: only navigate if actually opening (not closing)
    if (isOpen) await openApprovalsMenu();
  });

  // Approval sub-tab links
  document.querySelectorAll('.sidebar-sublink[data-tab]').forEach(btn => {
    btn.addEventListener('click', async () => {
      // FIX: await navigate so the page HTML is ready before switchTab runs
      if (router.current !== 'approvals') await router.navigate('approvals');
      approvals.switchTab(btn.dataset.tab);
    });
  });

  // Profile menu toggle
  document.getElementById('profile-btn')?.addEventListener('click', () => {
    document.getElementById('profileMenu')?.classList.toggle('show');
  });
  // Close profile menu on outside click
  document.addEventListener('click', e => {
    const dd = document.querySelector('.profile-dropdown');
    if (dd && !dd.contains(e.target))
      document.getElementById('profileMenu')?.classList.remove('show');
  });

  // Profile menu → Settings
  document.querySelectorAll('.profile-menu-item[data-page]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById('profileMenu')?.classList.remove('show');
      router.navigate(btn.dataset.page);
    });
  });

  // Logout
  document.getElementById('logout-btn')?.addEventListener('click', () => {
    showConfirm('Log out of HarvestHub Admin?', async () => {
      const overlay = document.getElementById('logout-overlay');
      if (overlay) overlay.classList.add('active');
      await new Promise(r => setTimeout(r, 400));
      await signOut(auth);
      window.location.replace('index.html');
    });
  });
}

// ── Shell-level modal wiring ──────────────────────────────────────────────────
function initShellModals() {
  // Wire all [data-close] buttons and overlay-click-to-close on the full document
  bindModalClose(document);

  // Lightbox close
  document.getElementById('lightbox-close')?.addEventListener('click', () => {
    document.getElementById('imageLightboxModal')?.classList.remove('open');
  });
  document.getElementById('imageLightboxModal')?.addEventListener('click', e => {
    if (e.target === e.currentTarget) e.currentTarget.classList.remove('open');
  });
}

// ── Boot ──────────────────────────────────────────────────────────────────────
initSidebar();
initShellModals();
notif.startPolling();

// Load dashboard on first visit
router.navigate('dashboard');
